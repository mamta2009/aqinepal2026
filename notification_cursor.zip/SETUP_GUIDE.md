# Early Warning System - Complete Setup Guide

## Part 1: Twilio Setup (SMS + WhatsApp)

### Step 1A: Get Your Twilio Credentials

1. **Login to Twilio**: https://www.twilio.com/console
2. **Copy these from Dashboard**:
   - Account SID: `ACxxxxxxxxxxxxxxxxxxxx`
   - Auth Token: `your_auth_token_here`
3. **Buy a Phone Number**:
   - Click "Phone Numbers" → "Active Numbers" → "Get Started"
   - Choose: Country = USA, Capabilities = SMS (check), Voice (optional)
   - Cost: $1/month
   - Example: `+1-617-555-0123`
4. **Save these in `.env`**:
   ```
   TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxx
   TWILIO_AUTH_TOKEN=your_auth_token_here
   TWILIO_PHONE_NUMBER=+1617555XXXX
   ```

### Step 1B: Setup WhatsApp - SANDBOX MODE (Testing)

**Use this for Week 1 testing — NO setup needed!**

1. Go to Twilio Console → Messaging → Try WhatsApp
2. Click "Confirm & Enable Sandbox"
3. You get a shared sandbox number: `+14155238886`
4. Add to `.env`:
   ```
   TWILIO_WHATSAPP_SANDBOX=+14155238886
   ENVIRONMENT=sandbox
   ```

**Health workers join the sandbox:**
- They save: `+14155238886` in WhatsApp
- They message: `join your-sandbox-code`
- (Twilio shows you the exact message to send)
- They're now registered and can receive test alerts

**Pros:**
- ✅ FREE
- ✅ No verification needed
- ✅ Test alerts via WhatsApp instantly
- ✅ Perfect for MVP

**Cons:**
- ❌ Sandbox number is Twilio's shared number
- ❌ Manually invite each user
- ❌ Not for production

**When to move to production:** After you've tested with 5+ health workers

---

### Step 1C: Setup WhatsApp - PRODUCTION MODE (Live)

**Do this in Week 2 after sandbox testing works**

1. **Register your Twilio phone number for WhatsApp**:
   - Go to Twilio Console → Messaging → WhatsApp → Get Started
   - Click "Self Sign-up"
   - You're taken to Meta's portal
   
2. **Create Meta Business Manager** (if you don't have one):
   - Login with Facebook or create new account
   - Free, takes 5 minutes
   
3. **Register your phone number**:
   - Select your USA phone number from earlier (`+1-617-555-XXXX`)
   - Choose verification method: SMS or Phone call
   - Meta sends OTP to your phone
   - Enter code and confirm
   
4. **Create WhatsApp Business Account**:
   - Done automatically during verification
   - Your phone number is now active for WhatsApp

5. **Update `.env`**:
   ```
   ENVIRONMENT=production
   TWILIO_PHONE_NUMBER=+1617555XXXX
   # (same phone for both SMS and WhatsApp)
   ```

**Now users message directly — no "join" needed!**

Health workers in production:
- Save your number in WhatsApp: `+1-617-555-XXXX`
- Get alerts directly
- Can reply to messages

---

## Part 2: Resend Email Setup

### Step 2A: Create Resend Account

1. Go to: https://resend.com
2. Sign up (GitHub or email)
3. Go to Dashboard → API Keys
4. Copy your API key: `re_xxxxxxxxxxxxxxxxxxxx`
5. Add to `.env`:
   ```
   RESEND_API_KEY=re_xxxxxxxxxxxxxxxxxxxx
   RESEND_FROM_EMAIL=alerts@early-warning.com
   ```

### Step 2B: Verify Sending Domain (Optional but Recommended)

For production emails:

1. Go to Resend Dashboard → Domains
2. Add your domain: `early-warning.com`
3. Add DNS records (Resend shows you which ones)
4. Wait for verification (2-5 minutes)
5. Update `.env`:
   ```
   RESEND_FROM_EMAIL=alerts@early-warning.com
   ```

**Without domain verification:**
- ✅ Still works (uses Resend's default domain)
- ❌ Looks like: `from: Resend <onboarding@resend.dev>`

**With custom domain:**
- ✅ Looks professional: `from: Early Warning <alerts@early-warning.com>`
- ⏱️ Takes 5 minutes to setup

---

## Part 3: MongoDB Atlas Setup

### Step 3A: Create Database

1. Go to: https://www.mongodb.com/cloud/atlas
2. Sign up (Google or email)
3. Create new project → "early_warning"
4. Create Cluster:
   - Provider: AWS
   - Region: Your location (US)
   - Tier: **M0 (FREE 512MB)**
   - Cluster name: "early-warning"
5. Click "Create Cluster" (wait 2-3 minutes)

### Step 3B: Setup Connection

1. Go to Security → Database Access
2. Create user:
   - Username: `admin`
   - Password: Generate (copy this!)
   - Add user
   
3. Go to Network Access
4. Add IP Address → Allow from anywhere (for now)

### Step 3C: Get Connection String

1. Click "Connect" on cluster
2. Choose "Drivers"
3. Copy connection string:
   ```
   mongodb+srv://admin:PASSWORD@cluster.mongodb.net/?retryWrites=true&w=majority
   ```
4. Replace `PASSWORD` with your password
5. Add to `.env`:
   ```
   DATABASE_URL=mongodb+srv://admin:YOUR_PASSWORD@cluster.mongodb.net/early_warning?retryWrites=true&w=majority
   ```

---

## Part 4: Complete `.env` File

Create `.env` file in your project root:

```bash
# ============================================
# ENVIRONMENT
# ============================================
ENVIRONMENT=sandbox  # Use "sandbox" or "production"

# ============================================
# TWILIO CONFIGURATION
# ============================================
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+1617555XXXX
TWILIO_WHATSAPP_SANDBOX=+14155238886

# ============================================
# RESEND EMAIL CONFIGURATION
# ============================================
RESEND_API_KEY=re_xxxxxxxxxxxxxxxxxxxx
RESEND_FROM_EMAIL=alerts@early-warning.com

# ============================================
# MONGODB CONFIGURATION
# ============================================
DATABASE_URL=mongodb+srv://admin:PASSWORD@cluster.mongodb.net/early_warning?retryWrites=true&w=majority

# ============================================
# API CONFIGURATION
# ============================================
API_HOST=0.0.0.0
API_PORT=8000
DEBUG=true
```

**Never commit `.env` to Git!** Add to `.gitignore`:
```
.env
.env.local
.env.*.local
```

---

## Part 5: Python Dependencies

### Install Requirements

Create `requirements.txt`:

```
fastapi==0.104.1
uvicorn==0.24.0
python-multipart==0.0.6
motor==3.3.2
pymongo==4.6.0
pydantic==2.5.0
pydantic-settings==2.1.0
python-dotenv==1.0.0
twilio==8.10.0
httpx==0.25.2
python-jose==3.3.0
passlib==1.7.4
```

Install:
```bash
pip install -r requirements.txt
```

---

## Part 6: Run Locally

### Start Backend

```bash
# From project root
python -m uvicorn main_notifications:app --reload

# API runs on: http://localhost:8000
# Auto-docs: http://localhost:8000/docs
```

### Open Registration Portal

```bash
# Open in browser
open registration_portal.html

# Or use a simple server
python -m http.server 8080
# Visit: http://localhost:8080/registration_portal.html
```

---

## Part 7: Test Each Channel

### Test SMS

```bash
curl -X POST http://localhost:8000/api/notifications/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient_id": "CONTACT_ID_HERE",
    "channel": "sms",
    "message": "Test SMS from Early Warning"
  }'
```

### Test WhatsApp (Sandbox)

```bash
curl -X POST http://localhost:8000/api/notifications/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient_id": "CONTACT_ID_HERE",
    "channel": "whatsapp",
    "message": "Test WhatsApp from Early Warning"
  }'
```

### Test Email

```bash
curl -X POST http://localhost:8000/api/notifications/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient_id": "CONTACT_ID_HERE",
    "channel": "email",
    "subject": "Test Email",
    "message": "This is a test email"
  }'
```

### Get Sandbox Info

```bash
curl http://localhost:8000/api/notifications/whatsapp/sandbox-info
```

Returns:
```json
{
  "sandbox_number": "+14155238886",
  "setup_instructions": {
    "step_1": "Save this number in your phone: +14155238886",
    "step_2": "Send WhatsApp message: 'join your-sandbox-keyword'",
    ...
  }
}
```

---

## Part 8: Database Setup Script

After backend starts, it auto-creates indexes:

```bash
# Check indexes created
# Open MongoDB Atlas → Collections → contacts
# You should see indexes for email, phone_number, etc.
```

To manually setup (optional):

```python
from motor.motor_asyncio import AsyncMotorClient

async def setup():
    client = AsyncMotorClient("mongodb+srv://...")
    db = client.early_warning
    
    # Create indexes
    await db.contacts.create_index("email", unique=True)
    await db.contacts.create_index("phone_number")
    await db.notification_logs.create_index("timestamp")
    
    print("✅ Database ready")
```

---

## Part 9: Health Worker Registration Flow (Week 1)

### Phase 1: Sandbox Testing

**Timeline: Days 1-3**

1. **You register yourself**:
   - Visit `registration_portal.html`
   - Enter your details
   - Choose: SMS, WhatsApp, Email
   - Check email for verification code
   - Enter code to verify

2. **Get sandbox WhatsApp ready**:
   - Go to `http://localhost:8000/api/notifications/whatsapp/sandbox-info`
   - Copy sandbox number: `+14155238886`
   - Copy sandbox keyword (Twilio shows you)

3. **Invite test health worker**:
   - Send them the sandbox setup instructions
   - They save the number in WhatsApp
   - They send: `join your-keyword`
   - They receive confirmation

4. **Send test alert**:
   - POST to `/api/alerts/broadcast`
   - They receive SMS + WhatsApp in seconds
   - Check MongoDB that messages were logged

### Phase 2: Production Setup

**Timeline: Day 4**

1. **Register for WhatsApp production**:
   - Go to Twilio WhatsApp → Self Sign-up
   - Follow Meta verification (5 minutes)
   - Update ENVIRONMENT=production in .env

2. **Register real health workers**:
   - Share `registration_portal.html`
   - They register online
   - They verify via SMS/email/WhatsApp
   - They get added to recipient database

3. **Send live alerts**:
   - `POST /api/alerts/broadcast`
   - All verified health workers get real alerts
   - You can track delivery in MongoDB `notification_logs`

---

## Part 10: Monitoring & Debugging

### View Sent Notifications

```bash
# Get all SMS sent today
curl http://localhost:8000/api/analytics/notifications?days=1

# Returns:
{
  "by_channel": [
    {"_id": "sms", "total": 25, "success": 24},
    {"_id": "whatsapp", "total": 20, "success": 20},
    {"_id": "email", "total": 15, "success": 15}
  ]
}
```

### Check Contact Registration

```bash
# Get all verified health workers
curl http://localhost:8000/api/contacts?contact_type=health_worker

# Returns list of all registered contacts
```

### Monitor Twilio

1. Go to Twilio Console → Monitor → Logs
2. See real-time SMS/WhatsApp sending
3. Check error codes if something fails

### Monitor Resend

1. Go to Resend Dashboard
2. See all emails sent/delivered/failed
3. Check bounce rates

### Monitor MongoDB

1. Go to MongoDB Atlas → Collections
2. View documents in `notification_logs`
3. Check `contacts` for registered users

---

## Part 11: Common Issues & Fixes

### Issue: "Twilio Auth Failed"
```
Error: 401 Unauthorized
```
**Fix**: Double-check TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN in .env

### Issue: "Phone number not in valid E.164 format"
```
Error: +1 617 555 0123 (spaces)
```
**Fix**: Use format: `+16175550123` (no spaces or dashes)

### Issue: "User hasn't joined WhatsApp sandbox"
```
Error: [63015] User is not part of our WhatsApp customer
```
**Fix**: Tell user to message `join KEYWORD` first

### Issue: "Failed to send email via Resend"
```
Error: Invalid API key
```
**Fix**: Copy RESEND_API_KEY correctly (starts with `re_`)

### Issue: "MongoDB connection timeout"
```
Error: MongoServerError: connect ECONNREFUSED
```
**Fix**: 
- Check DATABASE_URL is correct
- Add your IP to MongoDB Atlas Network Access
- Use: "Allow Access from Anywhere" (temporary during testing)

---

## Part 12: Production Deployment

After Week 1 sandbox testing works:

### Deploy to Render

See `RENDER_DEPLOYMENT_GUIDE.md`

### Set Render Environment Variables

Go to Render Dashboard → Settings → Environment:
```
TWILIO_ACCOUNT_SID=...
TWILIO_AUTH_TOKEN=...
TWILIO_PHONE_NUMBER=...
RESEND_API_KEY=...
RESEND_FROM_EMAIL=...
DATABASE_URL=...
ENVIRONMENT=production
```

### Webhook URLs

Update in your code:
```python
WEBHOOK_URL = "https://your-app.render.com/api/webhooks/sms"
```

Tell Twilio where to send webhooks:
- Twilio Console → Phone Numbers → Your number
- Messaging → Webhook URL: `https://your-app.render.com/api/webhooks/sms`

---

## Checklist: You're Ready When ✅

- [ ] Twilio Account setup
- [ ] Twilio Phone number purchased ($1/month)
- [ ] Resend API key created
- [ ] MongoDB Atlas database created
- [ ] `.env` file with all credentials
- [ ] Backend runs locally (`python -m uvicorn...`)
- [ ] Registration portal loads and submits
- [ ] SMS test succeeds
- [ ] WhatsApp sandbox test succeeds (at least you + 1 health worker)
- [ ] Email test succeeds
- [ ] MongoDB has contacts and notification logs

**Then you're ready to invite real health workers!**

---

## Quick Start Commands

```bash
# 1. Create .env file (copy Part 4 above)
nano .env

# 2. Install dependencies
pip install -r requirements.txt

# 3. Test backend startup
python -m uvicorn main_notifications:app --reload

# 4. In another terminal, test a contact
curl http://localhost:8000/api/contacts

# 5. Send test alert
curl -X POST http://localhost:8000/api/alerts/broadcast \
  -H "Content-Type: application/json" \
  -d '{
    "city": "Kathmandu",
    "aqi_value": 450,
    "aqi_level": "SEVERE",
    "recipient_type": "health_worker"
  }'

# 6. Check results in MongoDB Atlas dashboard
```

**You're live in 1 hour.** 🚀
