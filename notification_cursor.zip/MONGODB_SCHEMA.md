# Early Warning System - MongoDB Schema Documentation

## Database: `early_warning`

---

## Collection 1: `contacts`

**Purpose:** Store health workers, parents, and administrators for alert delivery

```javascript
{
  _id: ObjectId("6..."),
  
  // Personal Information
  name: "Dr. Sharma",
  email: "sharma@hospital.com",
  phone_number: "+1-617-555-0123",
  whatsapp_number: "+1-617-555-0123",
  
  // Registration Details
  contact_type: "health_worker",  // health_worker, parent, admin, government
  facility_id: "kathmandu_medical_center",
  facility_name: "Kathmandu Medical Center",
  language: "en",  // en, ne (Nepali)
  
  // Notification Preferences
  preferred_channels: ["sms", "whatsapp", "email"],
  
  // Consent & Verification
  consent_given: true,
  consent_timestamp: ISODate("2024-01-15T10:30:00Z"),
  verification_status: "verified",  // pending, verified, failed
  verification_code: "123456",
  verified_at: ISODate("2024-01-15T10:45:00Z"),
  
  // Activity Tracking
  active: true,
  created_at: ISODate("2024-01-15T10:00:00Z"),
  updated_at: ISODate("2024-01-15T10:45:00Z"),
  last_inbound_at: ISODate("2024-01-20T14:30:00Z"),
  
  // Metadata
  source: "web_registration",  // web_registration, sms_signup, api
  tags: ["key_contact", "respiratory_specialist"]
}
```

### Indexes
```javascript
db.contacts.createIndex({ email: 1 }, { unique: true })
db.contacts.createIndex({ phone_number: 1 })
db.contacts.createIndex({ whatsapp_number: 1 })
db.contacts.createIndex({ facility_id: 1 })
db.contacts.createIndex({ contact_type: 1 })
db.contacts.createIndex({ verification_status: 1 })
db.contacts.createIndex({ active: 1, created_at: -1 })
```

### Example Queries

```javascript
// Find all verified health workers
db.contacts.find({
  verification_status: "verified",
  contact_type: "health_worker"
})

// Find contacts who prefer WhatsApp
db.contacts.find({
  preferred_channels: "whatsapp",
  active: true
})

// Find all contacts at a facility
db.contacts.find({
  facility_id: "kathmandu_medical_center"
})
```

---

## Collection 2: `notification_logs`

**Purpose:** Track all sent notifications for analytics and debugging

```javascript
{
  _id: ObjectId("6..."),
  
  // Recipient Information
  recipient_id: ObjectId("6..."),  // Reference to contacts
  recipient_email: "sharma@hospital.com",
  recipient_name: "Dr. Sharma",
  
  // Message Details
  channel: "sms",  // sms, whatsapp, email
  message: "🔴 HIGH air quality alert in Kathmandu. AQI: 450",
  subject: "Air Quality Alert",  // For email
  type: "alert",  // alert, verification, reminder
  
  // Alert Context
  alert_level: "HIGH",  // LOW, MODERATE, HIGH, SEVERE
  city: "Kathmandu",
  aqi_value: 450,
  
  // Delivery Status
  status: "sent",  // sent, failed, pending
  delivery_status: "delivered",  // delivered, undelivered, failed
  twilio_sid: "SMxxxxxxxxxxxxxxxxxxxx",
  error: null,
  
  // Timestamps
  timestamp: ISODate("2024-01-20T14:30:00Z"),
  delivered_at: ISODate("2024-01-20T14:30:05Z"),
  
  // Retry Information
  retry_count: 0,
  last_retry: null
}
```

### Indexes
```javascript
db.notification_logs.createIndex({ recipient_id: 1, timestamp: -1 })
db.notification_logs.createIndex({ channel: 1, status: 1 })
db.notification_logs.createIndex({ timestamp: 1 })
db.notification_logs.createIndex({ alert_level: 1 })
db.notification_logs.createIndex({ city: 1, timestamp: -1 })
```

### Example Queries

```javascript
// Count deliveries in last 24 hours
db.notification_logs.countDocuments({
  timestamp: { $gte: new Date(Date.now() - 24*60*60*1000) }
})

// Get delivery rate by channel
db.notification_logs.aggregate([
  { $match: { timestamp: { $gte: new Date(Date.now() - 7*24*60*60*1000) } } },
  { $group: {
    _id: "$channel",
    total: { $sum: 1 },
    delivered: { $sum: { $cond: ["$status", 1, 0] } }
  }}
])

// Find failed messages for retry
db.notification_logs.find({
  status: "failed",
  retry_count: { $lt: 3 },
  timestamp: { $gte: new Date(Date.now() - 24*60*60*1000) }
})
```

---

## Collection 3: `consent_records`

**Purpose:** Audit trail of consent changes for compliance

```javascript
{
  _id: ObjectId("6..."),
  
  // Reference
  contact_id: ObjectId("6..."),  // Reference to contacts
  contact_email: "sharma@hospital.com",
  
  // Consent Status
  consent_given: true,
  channels: ["sms", "whatsapp", "email"],
  
  // Timestamps
  timestamp: ISODate("2024-01-15T10:30:00Z"),
  
  // Change Details
  change_type: "initial_registration",  // initial_registration, preference_update, opt_out
  previous_channels: null,
  reason: "User updated preferences"
}
```

### Indexes
```javascript
db.consent_records.createIndex({ contact_id: 1, timestamp: -1 })
db.consent_records.createIndex({ timestamp: 1 })
```

---

## Collection 4: `inbound_messages`

**Purpose:** Store incoming SMS/WhatsApp messages from health workers

```javascript
{
  _id: ObjectId("6..."),
  
  // Message Details
  type: "sms",  // sms, whatsapp
  from: "+1-617-555-0123",
  body: "We've stocked oxygen tanks as recommended",
  
  // Reference
  twilio_sid: "SMxxxxxxxxxxxxxxxxxxxx",
  
  // Status
  processed: false,
  processed_at: null,
  
  // Timestamps
  timestamp: ISODate("2024-01-20T15:00:00Z")
}
```

### Indexes
```javascript
db.inbound_messages.createIndex({ from: 1, timestamp: -1 })
db.inbound_messages.createIndex({ timestamp: 1 })
db.inbound_messages.createIndex({ processed: 1 })
```

---

## Collection 5: `alert_broadcasts`

**Purpose:** Track alert broadcast campaigns

```javascript
{
  _id: ObjectId("6..."),
  
  // Alert Information
  city: "Kathmandu",
  aqi_level: "SEVERE",
  aqi_value: 450,
  
  // Broadcast Results
  results: {
    sms: {
      sent: 45,
      failed: 2
    },
    whatsapp: {
      sent: 38,
      failed: 1
    },
    email: {
      sent: 42,
      failed: 0
    }
  },
  
  total_recipients: 50,
  
  // Timestamps
  timestamp: ISODate("2024-01-20T14:30:00Z")
}
```

### Indexes
```javascript
db.alert_broadcasts.createIndex({ city: 1, timestamp: -1 })
db.alert_broadcasts.createIndex({ timestamp: 1 })
db.alert_broadcasts.createIndex({ aqi_level: 1 })
```

---

## Collection 6: `facilities`

**Purpose:** Health facility registry

```javascript
{
  _id: ObjectId("6..."),
  
  // Facility Information
  facility_id: "kathmandu_medical_center",
  name: "Kathmandu Medical Center",
  city: "Kathmandu",
  district: "Kathmandu",
  
  // Contact
  phone: "+977-1-4123456",
  email: "info@kmc.com",
  address: "Kathmandu, Nepal",
  
  // Capabilities
  capacity_beds: 150,
  respiratory_ward: true,
  oxygen_available: true,
  
  // Status
  active: true,
  registered_at: ISODate("2024-01-10T10:00:00Z"),
  
  // Metadata
  latitude: 27.7172,
  longitude: 85.3240,
  tags: ["public", "respiratory_specialist"]
}
```

---

## Collection 7: `action_logs`

**Purpose:** Track health worker responses to alerts (facility actions taken)

```javascript
{
  _id: ObjectId("6..."),
  
  // References
  contact_id: ObjectId("6..."),
  facility_id: "kathmandu_medical_center",
  alert_id: ObjectId("6..."),
  
  // Action Details
  action: "stocked_oxygen",  // stocked_oxygen, staff_called, prepared_ward, etc.
  description: "Stocked additional oxygen tanks from supplies",
  status: "completed",  // pending, completed, failed
  
  // Response Time
  alert_received_at: ISODate("2024-01-20T14:30:00Z"),
  action_taken_at: ISODate("2024-01-20T14:45:00Z"),
  response_time_minutes: 15,
  
  // Metadata
  timestamp: ISODate("2024-01-20T14:45:00Z")
}
```

### Indexes
```javascript
db.action_logs.createIndex({ facility_id: 1, timestamp: -1 })
db.action_logs.createIndex({ contact_id: 1 })
db.action_logs.createIndex({ alert_id: 1 })
```

---

## Collection 8: `respiratory_cases`

**Purpose:** Daily respiratory case counts from facilities

```javascript
{
  _id: ObjectId("6..."),
  
  // Date Information
  date: ISODate("2024-01-20T00:00:00Z"),
  facility_id: "kathmandu_medical_center",
  
  // Case Counts
  admissions: 12,
  readmissions: 2,
  severe_cases: 3,
  oxygen_required: 8,
  
  // Outcomes
  discharges: 5,
  deaths: 0,
  
  // Reporting
  reported_by: ObjectId("6..."),  // Reference to contact (health worker)
  reported_at: ISODate("2024-01-20T16:00:00Z"),
  verified: false
}
```

### Indexes
```javascript
db.respiratory_cases.createIndex({ facility_id: 1, date: -1 })
db.respiratory_cases.createIndex({ date: 1 })
```

---

## Collection 9: `settings`

**Purpose:** System configuration

```javascript
{
  _id: "system_config",
  
  // Alert Thresholds
  alert_thresholds: {
    low: 0,
    moderate: 50,
    high: 150,
    severe: 300
  },
  
  // SMS Settings
  sms_enabled: true,
  sms_cost_per_message: 0.0075,
  
  // WhatsApp Settings
  whatsapp_enabled: true,
  whatsapp_use_sandbox: false,
  
  // Email Settings
  email_enabled: true,
  email_from: "alerts@early-warning.com",
  
  // Notification Schedule
  broadcast_schedule: "every_6_hours",
  
  // Updated
  updated_at: ISODate("2024-01-15T10:00:00Z")
}
```

---

## Data Retention Policy

```javascript
// Auto-delete old notification logs after 90 days
db.notification_logs.createIndex(
  { timestamp: 1 },
  { expireAfterSeconds: 90*24*60*60 }
)

// Keep inbound messages for 30 days
db.inbound_messages.createIndex(
  { timestamp: 1 },
  { expireAfterSeconds: 30*24*60*60 }
)

// Keep contact records indefinitely (for compliance)
// Keep consent records indefinitely (for audit trail)
```

---

## Storage Estimate

For a 6-month pilot with 5 facilities and 100 health workers:

```
contacts:               100 × 1KB              = 100 KB
notification_logs:      50K msgs × 0.5KB      = 25 MB
consent_records:        500 × 0.5KB           = 250 KB
inbound_messages:       10K × 0.3KB           = 3 MB
alert_broadcasts:       180 × 1KB             = 180 KB
respiratory_cases:      5 facilities × 180 days = 900 docs × 0.5KB = 450 KB
action_logs:            5K × 0.5KB            = 2.5 MB
facilities:             5 × 2KB               = 10 KB
settings:               1 × 1KB               = 1 KB
                                        ─────────────
                                        ~32 MB total
```

**Actual usage:** ~50-100 MB (with indexes)  
**Free tier includes:** 512 MB  
**Conclusion:** Easily fits on MongoDB Atlas free tier for 6+ months

---

## Backup & Recovery

### Daily Backup (MongoDB Atlas Free Tier)
```
- Automatic daily backups
- Retention: 7 days
- Restoration point: Any time in last 7 days
```

### Manual Backup
```bash
# Export contacts for compliance
mongodump --uri "mongodb+srv://..." --collection contacts

# Export consent audit trail
mongodump --uri "mongodb+srv://..." --collection consent_records
```

---

## Sample MongoDB Connection

```python
from motor.motor_asyncio import AsyncMotorClient

DATABASE_URL = "mongodb+srv://user:password@cluster.mongodb.net/early_warning?retryWrites=true&w=majority"

client = AsyncMotorClient(DATABASE_URL)
db = client.early_warning

# Now use collections
contacts = db.contacts
notifications = db.notification_logs
```

---

## Compliance Notes

✅ **GDPR Compliant:**
- Consent records for audit trail
- Easy data deletion (delete from contacts collection)
- Data retention policies with auto-expiry

✅ **HIPAA Ready:**
- Separate consent collection
- Audit trail for all changes
- Encryption in transit (MongoDB Atlas SSL)

✅ **Child-Safe:**
- Parent consent required
- Separate parent/child tracking
- Opt-out mechanism honored immediately
