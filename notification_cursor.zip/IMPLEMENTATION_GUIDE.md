# Early Warning System - Implementation Reference

## Quick Summary: What You Get

### 1. **Backend** (`main_notifications.py`)
- 30+ API endpoints for registrations, alerts, and webhooks
- Full Twilio SMS/WhatsApp integration
- Resend email integration
- MongoDB schema with all collections
- Webhook handlers for replies

### 2. **Frontend** (`registration_portal.html`)
- Beautiful health worker registration form
- Multi-channel preference selector
- Consent & privacy checkboxes
- Real-time validation
- Mobile responsive

### 3. **Database** (`MONGODB_SCHEMA.md`)
- 9 collections documented
- Sample queries
- Compliance notes (GDPR, HIPAA)
- Data retention policies

---

## Implementation Timeline

### Week 1: Sandbox Testing

**Goal:** Get SMS + WhatsApp + Email working with yourself

**Day 1 (2 hours)**
```
1. Create Twilio account → copy credentials
2. Create Resend account → copy API key
3. Create MongoDB database → copy connection string
4. Create .env file with all credentials
5. Run backend locally
```

**Day 2 (2 hours)**
```
1. Open registration_portal.html in browser
2. Register yourself
3. Verify via email
4. Test SMS to yourself
5. Test email to yourself
```

**Day 3 (2 hours)**
```
1. Setup WhatsApp sandbox
2. Join your own sandbox
3. Send WhatsApp test message
4. Broadcast test alert to yourself via all 3 channels
5. Check MongoDB for logs
```

**Day 4-7 (4 hours)**
```
1. Register 5 test health workers
2. They join WhatsApp sandbox
3. Send broadcast alerts
4. Get feedback on UI/UX
5. Fix any issues
```

### Week 2: Production

**Day 8 (2 hours)**
```
1. Register WhatsApp production
2. Update ENVIRONMENT=production
3. Deploy backend to Render
4. Share registration_portal.html publicly
```

**Day 9-14 (8 hours)**
```
1. Real health workers register online
2. Verify registrations
3. Send real AQI alerts
4. Track delivery metrics
5. Iterate based on feedback
```

---

## Code Examples by Use Case

### Use Case 1: A Health Worker Registers

**Flow:**
1. Opens `registration_portal.html`
2. Fills form → clicks "Register"
3. Form posts to `/api/contacts/register`
4. Backend creates contact in MongoDB
5. Sends verification email + SMS
6. Health worker gets code, enters it
7. Contact moves to "verified" status

**Frontend code (in registration_portal.html):**
```javascript
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
        name: "Dr. Sharma",
        email: "sharma@hospital.com",
        phone_number: "+1-617-555-0123",
        whatsapp_number: "+1-617-555-0123",
        contact_type: "health_worker",
        facility_name: "Kathmandu Medical Center",
        preferred_channels: ["sms", "whatsapp", "email"],
        consent_given: true
    };
    
    const response = await fetch('/api/contacts/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
    });
    
    const result = await response.json();
    console.log("Registered! Contact ID:", result.contact_id);
});
```

**Backend code (in main_notifications.py):**
```python
@app.post("/api/contacts/register")
async def register_contact(contact: ContactRegistration):
    # Validate & normalize phone
    normalized_phone = contact.phone_number.replace(" ", "").replace("-", "")
    
    # Check if email exists
    existing = await db.contacts.find_one({"email": contact.email})
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")
    
    # Create contact document
    contact_doc = {
        "name": contact.name,
        "email": contact.email,
        "phone_number": normalized_phone,
        "whatsapp_number": contact.whatsapp_number or normalized_phone,
        "contact_type": contact.contact_type.value,
        "preferred_channels": [ch.value for ch in contact.preferred_channels],
        "consent_given": contact.consent_given,
        "created_at": datetime.utcnow(),
        "verification_status": "pending"
    }
    
    result = await db.contacts.insert_one(contact_doc)
    contact_id = str(result.inserted_id)
    
    # Send verification emails/SMS
    await send_verification_email(contact_id, contact.email, contact.name)
    
    return {
        "success": True,
        "contact_id": contact_id,
        "message": "Check your email for verification code"
    }
```

**Database (MongoDB):**
```javascript
// contacts collection stores:
{
  _id: ObjectId("6..."),
  name: "Dr. Sharma",
  email: "sharma@hospital.com",
  phone_number: "+16175550123",
  whatsapp_number: "+16175550123",
  contact_type: "health_worker",
  preferred_channels: ["sms", "whatsapp", "email"],
  consent_given: true,
  verification_status: "pending",
  created_at: ISODate("2024-01-15T10:00:00Z")
}
```

---

### Use Case 2: System Sends AQI Alert

**Flow:**
1. Every 6 hours, air quality data arrives
2. If AQI > 300 → trigger alert
3. Broadcast to all verified health workers
4. Each contact gets SMS + WhatsApp + Email
5. All notifications logged to MongoDB

**Backend code:**
```python
@app.post("/api/alerts/broadcast")
async def broadcast_alert(alert: AlertBroadcast, background_tasks: BackgroundTasks):
    
    # Build alert message
    alert_message = f"""🔴 AIR QUALITY ALERT

City: {alert.city}
AQI Level: {alert.aqi_level.value}
AQI Value: {alert.aqi_value}

Actions: Check oxygen stock, alert staff"""
    
    # Get all verified contacts
    recipients = await db.contacts.find({
        "active": True,
        "consent_given": True,
        "verification_status": "verified"
    }).to_list(length=5000)
    
    # Send in background (don't block)
    background_tasks.add_task(
        broadcast_to_recipients,
        recipients,
        alert_message,
        alert.aqi_level.value,
        alert.city
    )
    
    return {
        "success": True,
        "recipients_count": len(recipients),
        "message": "Alert broadcast initiated"
    }


async def broadcast_to_recipients(recipients, message, aqi_level, city):
    """Background task to send to all"""
    
    for recipient in recipients:
        # Send SMS
        if "sms" in recipient.get("preferred_channels", []):
            result = await send_sms(recipient["phone_number"], message)
            
            # Log to database
            await db.notification_logs.insert_one({
                "recipient_id": str(recipient["_id"]),
                "channel": "sms",
                "status": result["status"],
                "timestamp": datetime.utcnow()
            })
        
        # Send WhatsApp
        if "whatsapp" in recipient.get("preferred_channels", []):
            result = await send_whatsapp(
                recipient["whatsapp_number"],
                message,
                use_sandbox=(ENVIRONMENT == "sandbox")
            )
            
            await db.notification_logs.insert_one({
                "recipient_id": str(recipient["_id"]),
                "channel": "whatsapp",
                "status": result["status"],
                "timestamp": datetime.utcnow()
            })
        
        # Send Email
        if "email" in recipient.get("preferred_channels", []):
            html = f"<h2>{city} - {aqi_level}</h2><p>{message}</p>"
            result = await send_email(
                recipient["email"],
                f"AIR QUALITY ALERT - {aqi_level}",
                html
            )
            
            await db.notification_logs.insert_one({
                "recipient_id": str(recipient["_id"]),
                "channel": "email",
                "status": result["status"],
                "timestamp": datetime.utcnow()
            })
```

**Trigger this alert (example):**
```bash
curl -X POST http://localhost:8000/api/alerts/broadcast \
  -H "Content-Type: application/json" \
  -d '{
    "city": "Kathmandu",
    "aqi_value": 450,
    "aqi_level": "SEVERE",
    "recipient_type": "health_worker"
  }'
```

**Result in MongoDB notification_logs:**
```javascript
{
  _id: ObjectId("7..."),
  recipient_id: "6...",
  channel: "sms",
  status: "sent",
  city: "Kathmandu",
  aqi_level: "SEVERE",
  timestamp: ISODate("2024-01-20T14:30:00Z")
}
```

---

### Use Case 3: Health Worker Gets Notification

**SMS (via Twilio):**
```
🔴 AIR QUALITY ALERT

City: Kathmandu
AQI Level: SEVERE
AQI Value: 450

Actions: Check oxygen stock, alert staff
```

**WhatsApp (via Twilio):**
Same message arrives in WhatsApp

**Email (via Resend):**
```
Subject: AIR QUALITY ALERT - SEVERE

Kathmandu - SEVERE

🔴 AIR QUALITY ALERT

City: Kathmandu
AQI Level: SEVERE
AQI Value: 450

Actions: Check oxygen stock, alert staff
```

---

### Use Case 4: Health Worker Replies

**Flow:**
1. Health worker replies to SMS: "Stocked oxygen"
2. Twilio webhook receives the message
3. Backend stores in inbound_messages collection
4. Backend sends auto-reply

**Backend webhook:**
```python
@app.post("/api/webhooks/sms")
async def handle_sms_webhook(request: Request):
    form_data = await request.form()
    from_number = form_data.get("From")
    message_body = form_data.get("Body")
    
    # Store in database
    await db.inbound_messages.insert_one({
        "type": "sms",
        "from": from_number,
        "body": message_body,
        "timestamp": datetime.utcnow()
    })
    
    # Send auto-reply
    twilio_client.messages.create(
        body="Thank you! We received: " + message_body[:50],
        from_=TWILIO_PHONE_NUMBER,
        to=from_number
    )
    
    return {"success": True}
```

**Stored in MongoDB inbound_messages:**
```javascript
{
  _id: ObjectId("8..."),
  type: "sms",
  from: "+1-617-555-0123",
  body: "Stocked oxygen, facility ready",
  timestamp: ISODate("2024-01-20T14:35:00Z")
}
```

---

### Use Case 5: View Analytics

**Get delivery statistics:**
```bash
curl http://localhost:8000/api/analytics/notifications?days=7
```

**Response:**
```json
{
  "period_days": 7,
  "by_channel": [
    {"_id": "sms", "total": 150, "success": 148},
    {"_id": "whatsapp", "total": 120, "success": 119},
    {"_id": "email", "total": 100, "success": 100}
  ],
  "by_alert_level": [
    {"_id": "HIGH", "count": 45},
    {"_id": "SEVERE", "count": 12}
  ]
}
```

**MongoDB query to get this:**
```python
@app.get("/api/analytics/notifications")
async def get_notification_analytics(days: int = 7):
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Count by channel
    pipeline = [
        {"$match": {"timestamp": {"$gte": start_date}}},
        {"$group": {
            "_id": "$channel",
            "total": {"$sum": 1},
            "success": {"$sum": {"$cond": [{"$eq": ["$status", "sent"]}, 1, 0]}}
        }}
    ]
    
    channel_stats = await db.notification_logs.aggregate(pipeline).to_list(None)
    
    return {"by_channel": channel_stats}
```

---

## Running Everything Together

### Terminal 1: Start Backend
```bash
python -m uvicorn main_notifications:app --reload
```

Output:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
✅ Connected to MongoDB
✅ Database indexes created
✅ Notification API started in sandbox mode
```

### Terminal 2: View API Docs
```bash
# Open browser to:
http://localhost:8000/docs
```

You'll see Swagger UI with all endpoints interactive

### Terminal 3: Test Contacts Endpoint
```bash
curl http://localhost:8000/api/contacts

# Returns empty list (no contacts yet)
[]
```

### Browser: Open Registration Portal
```bash
open registration_portal.html
```

Fill form:
- Name: Your Name
- Email: your@email.com
- Phone: +1617555XXXX (your Twilio number)
- Channels: All 3
- Consent: Checked
- Submit

Check:
- ✅ Email arrived with verification code
- ✅ SMS arrived with verification code
- ✅ MongoDB has new contact

### Verify Contact
```bash
curl -X POST http://localhost:8000/api/contacts/verify \
  -H "Content-Type: application/json" \
  -d '{
    "contact_id": "CONTACT_ID_FROM_REGISTER",
    "verification_code": "123456"
  }'

# Returns: {"success": true, "message": "Contact verified successfully"}
```

### Broadcast Alert
```bash
curl -X POST http://localhost:8000/api/alerts/broadcast \
  -H "Content-Type: application/json" \
  -d '{
    "city": "Kathmandu",
    "aqi_value": 450,
    "aqi_level": "SEVERE",
    "recipient_type": "all"
  }'

# You receive:
# ✅ SMS immediately
# ✅ WhatsApp immediately
# ✅ Email immediately
```

### Check Analytics
```bash
curl http://localhost:8000/api/analytics/notifications?days=1

# Returns stats of what was just sent
```

---

## File Structure

```
project/
├── main_notifications.py              # All backend code
├── registration_portal.html            # All frontend code
├── SETUP_GUIDE.md                      # This file
├── MONGODB_SCHEMA.md                   # Database docs
├── requirements.txt                    # Python dependencies
├── .env                                # Your secrets (not in git)
├── .gitignore                          # Ignore .env
└── README.md                           # Project overview
```

---

## Deployment Checklist

Before going live:

- [ ] All tests pass locally
- [ ] 5+ test users registered and verified
- [ ] SMS test to real phone works
- [ ] WhatsApp test works
- [ ] Email test works
- [ ] Analytics endpoint works
- [ ] MongoDB backup tested
- [ ] `.env` has production credentials
- [ ] Deployed to Render
- [ ] Webhooks configured in Twilio
- [ ] Custom domain setup (optional)
- [ ] Health worker training materials ready
- [ ] Support email monitored

---

## Common Integration Points

### Add to Existing Flask/Django App

In your main app:

```python
# your_existing_app.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import main_notifications

app = FastAPI()

# Add CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount notification routes
app.include_router(main_notifications.router, prefix="/api")
```

### Trigger Alerts from Cron Job

```python
# In your AQI monitoring service
async def check_aqi_and_alert():
    aqi_data = get_aqi_from_iqair()
    
    if aqi_data["aqi"] > 300:
        # Call our broadcast endpoint
        response = await httpx.AsyncClient().post(
            "http://localhost:8000/api/alerts/broadcast",
            json={
                "city": "Kathmandu",
                "aqi_value": aqi_data["aqi"],
                "aqi_level": "HIGH" if aqi_data["aqi"] < 500 else "SEVERE",
                "recipient_type": "health_worker"
            }
        )
        print(f"Broadcast response: {response.json()}")
```

---

## Next Steps

1. ✅ **This week:** Complete Setup Guide Part 1-5
2. ✅ **Day 1-3:** Get sandbox SMS + WhatsApp + Email working with yourself
3. ✅ **Day 4-7:** Register 5 test health workers, send test alerts
4. ✅ **Week 2:** Deploy to production, register real health workers
5. ✅ **Week 3+:** Iterate based on feedback, add more facilities

**You have everything you need. Go build! 🚀**
