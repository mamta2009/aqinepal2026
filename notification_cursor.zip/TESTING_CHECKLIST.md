# Testing Checklist - Early Warning System

## Day 1: Setup & Configuration ✅

### Twilio Setup
- [ ] Created Twilio account (free $30 credit)
- [ ] Copied Account SID and Auth Token
- [ ] Purchased USA phone number (+1-XXX-XXX-XXXX)
- [ ] Copied phone number to .env
- [ ] Enabled WhatsApp Sandbox
- [ ] Copied sandbox number to .env

### Resend Setup
- [ ] Created Resend account
- [ ] Generated API key
- [ ] Copied API key to .env
- [ ] Set RESEND_FROM_EMAIL in .env

### MongoDB Setup
- [ ] Created MongoDB Atlas account
- [ ] Created cluster (free M0 tier)
- [ ] Created database user
- [ ] Copied connection string to .env
- [ ] Added IP to Network Access

### Environment File
- [ ] Created `.env` file
- [ ] All 9 variables filled in
- [ ] Double-checked for typos
- [ ] Added `.env` to `.gitignore`

**Verification Command:**
```bash
python -c "import os; from dotenv import load_dotenv; load_dotenv(); print('✅ All env vars loaded')"
```

---

## Day 2: Backend Testing 🚀

### Installation
- [ ] Created `requirements.txt`
- [ ] Ran `pip install -r requirements.txt`
- [ ] No errors during installation

### Backend Startup
```bash
python -m uvicorn main_notifications:app --reload
```

Check for:
- [ ] "✅ Connected to MongoDB"
- [ ] "✅ Database indexes created"
- [ ] "✅ Notification API started in sandbox mode"
- [ ] "Uvicorn running on http://0.0.0.0:8000"

### Health Check
```bash
curl http://localhost:8000/api/health
```

Expected response:
```json
{
  "status": "healthy",
  "service": "Early Warning Notifications API",
  "environment": "sandbox"
}
```

- [ ] Returns 200 status
- [ ] Shows "healthy" status
- [ ] Environment shows "sandbox"

### API Documentation
- [ ] Visit http://localhost:8000/docs
- [ ] See Swagger UI with all endpoints
- [ ] Can expand each endpoint
- [ ] See request/response schemas

### Database Connection
- [ ] Go to MongoDB Atlas
- [ ] Click on cluster
- [ ] See "Connected" status
- [ ] Can browse collections (empty for now)

**Result: ✅ Backend is running and connected to database**

---

## Day 3: Contact Registration Testing 📝

### Registration Portal
- [ ] Opened `registration_portal.html` in browser
- [ ] Form appears with all fields
- [ ] Form is mobile responsive (test on phone if possible)

### Test Self-Registration
Fill form with:
```
Name: Your Name
Email: your-email@gmail.com
Phone: +1-617-555-0123 (your Twilio number)
WhatsApp: (leave empty to use same)
Role: Health Worker
Facility: Test Facility
Language: English
Channels: SMS, WhatsApp, Email (all checked)
Consent: Both boxes checked
```

Click "Register & Verify"

Check for:
- [ ] Success message appears
- [ ] Form clears
- [ ] No error messages

### Check Email
- [ ] Email arrives from Resend (check spam folder)
- [ ] Subject: "Verify Your Early Warning System Account"
- [ ] Contains verification code (6 digits)
- [ ] Contains verification link

**Example verification code:** `123456`

### Check SMS
- [ ] SMS arrives from Twilio number
- [ ] Contains verification code
- [ ] Message: "Your Early Warning verification code is: 123456"

### Check MongoDB
Open MongoDB Atlas → Collections → contacts

Should see:
```javascript
{
  name: "Your Name",
  email: "your-email@gmail.com",
  phone_number: "+16175550123",
  whatsapp_number: "+16175550123",
  contact_type: "health_worker",
  preferred_channels: ["sms", "whatsapp", "email"],
  consent_given: true,
  verification_status: "pending"
}
```

Check for:
- [ ] Contact created with correct fields
- [ ] Phone numbers normalized (no spaces/dashes)
- [ ] Verification status = "pending"
- [ ] Created timestamp present

### Verify Contact
In terminal:
```bash
# Get the contact_id from MongoDB
CONTACT_ID="60b7d7c8d3c4e5f6g7h8i9j0"

curl -X POST http://localhost:8000/api/contacts/verify \
  -H "Content-Type: application/json" \
  -d "{
    \"contact_id\": \"$CONTACT_ID\",
    \"verification_code\": \"123456\"
  }"
```

Expected response:
```json
{
  "success": true,
  "message": "Contact verified successfully"
}
```

Check for:
- [ ] Returns 200 status
- [ ] Shows success message

### Check Verification in MongoDB
Refresh MongoDB Atlas

Should see:
```javascript
{
  verification_status: "verified",
  verified_at: ISODate("2024-01-15T10:45:00Z")
}
```

Check for:
- [ ] Verification status = "verified"
- [ ] Verified timestamp present

**Result: ✅ Registration and verification working end-to-end**

---

## Day 4: SMS Notification Testing 💬

### Get Your Contact ID
In MongoDB Atlas:
- Click contacts collection
- Find your document
- Copy the `_id` field

Example: `60b7d7c8d3c4e5f6g7h8i9j0`

### Send Test SMS
```bash
curl -X POST http://localhost:8000/api/notifications/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient_id": "60b7d7c8d3c4e5f6g7h8i9j0",
    "channel": "sms",
    "message": "Test SMS from Early Warning System",
    "alert_level": "HIGH"
  }'
```

Expected response:
```json
{
  "success": true,
  "channel": "sms",
  "recipient": "Your Name",
  "status": "sent"
}
```

Check for:
- [ ] Returns 200 status
- [ ] Shows "success": true
- [ ] Shows "status": "sent"

### Receive SMS
- [ ] SMS arrives on your phone within 2 seconds
- [ ] From: Twilio number
- [ ] Body: "Test SMS from Early Warning System"

### Check MongoDB notification_logs
```javascript
// Should see:
{
  recipient_id: "60b7d7c8d3c4e5f6g7h8i9j0",
  channel: "sms",
  message: "Test SMS from Early Warning System",
  status: "sent",
  alert_level: "HIGH",
  timestamp: ISODate("2024-01-15T11:00:00Z")
}
```

Check for:
- [ ] notification_logs collection created
- [ ] Entry with channel = "sms"
- [ ] Status = "sent"
- [ ] Timestamp recent

### Monitor in Twilio
- [ ] Open Twilio Console → Monitor → Logs
- [ ] Find your sent SMS
- [ ] Shows "Delivered" or "Sent"
- [ ] No error codes

**Result: ✅ SMS sending and logging working**

---

## Day 5: WhatsApp Sandbox Testing 🟢

### Join WhatsApp Sandbox

From earlier, you got a sandbox code. Let's say it's: `twilio-123`

**On your phone:**
1. Open WhatsApp
2. Save number: `+14155238886`
3. Send message: `join twilio-123`
4. Wait for reply: "You are all set!..."

Check for:
- [ ] Automatic reply arrives within 10 seconds
- [ ] Message confirms sandbox joined
- [ ] Can now receive WhatsApp messages

### Send Test WhatsApp
```bash
curl -X POST http://localhost:8000/api/notifications/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient_id": "60b7d7c8d3c4e5f6g7h8i9j0",
    "channel": "whatsapp",
    "message": "🔴 Test WhatsApp Alert from Early Warning"
  }'
```

Expected response:
```json
{
  "success": true,
  "channel": "whatsapp",
  "status": "sent"
}
```

### Receive WhatsApp
- [ ] Message arrives on WhatsApp from +14155238886
- [ ] Body: "🔴 Test WhatsApp Alert from Early Warning"
- [ ] Within 5 seconds

### Check MongoDB notification_logs
Should see entry with:
- [ ] channel = "whatsapp"
- [ ] status = "sent"

**Result: ✅ WhatsApp Sandbox working**

---

## Day 6: Email Testing 📧

### Send Test Email
```bash
curl -X POST http://localhost:8000/api/notifications/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient_id": "60b7d7c8d3c4e5f6g7h8i9j0",
    "channel": "email",
    "subject": "Test Alert from Early Warning",
    "message": "This is a test email notification"
  }'
```

Expected response:
```json
{
  "success": true,
  "channel": "email",
  "status": "sent"
}
```

### Receive Email
- [ ] Email arrives (check inbox and spam)
- [ ] From: alerts@early-warning.com (or Resend default)
- [ ] Subject: "Test Alert from Early Warning"
- [ ] Body: "This is a test email notification"
- [ ] Within 30 seconds

### Check Resend Dashboard
- [ ] Go to Resend Dashboard
- [ ] Click "Emails"
- [ ] See your test email
- [ ] Status: "Delivered"

### Check MongoDB notification_logs
Should see entry with:
- [ ] channel = "email"
- [ ] status = "sent"

**Result: ✅ Email working**

---

## Day 7: Broadcast Alert Testing 🎯

### Create Test Contact
Register a second contact (use different email):

```
Name: Test Health Worker 2
Email: test2@gmail.com
Phone: +1-XXX-XXX-XXXX (if you have another number)
Role: Health Worker
Consent: Checked
Channels: All 3
```

Then verify this contact too.

### Broadcast Alert
```bash
curl -X POST http://localhost:8000/api/alerts/broadcast \
  -H "Content-Type: application/json" \
  -d '{
    "city": "Kathmandu",
    "aqi_value": 450,
    "aqi_level": "SEVERE",
    "recipient_type": "health_worker"
  }'
```

Expected response:
```json
{
  "success": true,
  "alert_id": "2024-01-15T11:15:00.123456",
  "recipients_count": 2,
  "city": "Kathmandu",
  "aqi_level": "SEVERE",
  "message": "Alert broadcast initiated"
}
```

Check for:
- [ ] Shows recipients_count > 0
- [ ] Says "broadcast initiated"

### Receive Broadcasts
For each contact, should receive:
- [ ] SMS: "🔴 AIR QUALITY ALERT..."
- [ ] WhatsApp: Same message on WhatsApp
- [ ] Email: HTML formatted alert

Check for:
- [ ] All 3 channels deliver
- [ ] Message contains: City, AQI Level, AQI Value, Actions
- [ ] Arrives within 5 seconds

### Monitor Broadcast
```bash
curl http://localhost:8000/api/analytics/notifications?days=1
```

Should show:
```json
{
  "by_channel": [
    {"_id": "sms", "total": 2, "success": 2},
    {"_id": "whatsapp", "total": 2, "success": 2},
    {"_id": "email", "total": 2, "success": 2}
  ]
}
```

Check for:
- [ ] SMS: 2 sent, 2 success
- [ ] WhatsApp: 2 sent, 2 success
- [ ] Email: 2 sent, 2 success

### Check MongoDB alert_broadcasts
Should see:
```javascript
{
  city: "Kathmandu",
  aqi_level: "SEVERE",
  aqi_value: 450,
  timestamp: ISODate(...),
  results: {
    sms: { sent: 2, failed: 0 },
    whatsapp: { sent: 2, failed: 0 },
    email: { sent: 2, failed: 0 }
  },
  total_recipients: 2
}
```

**Result: ✅ Broadcast to multiple users working**

---

## Week 2: Production Testing

### WhatsApp Production Setup
- [ ] Completed WhatsApp Self Sign-up
- [ ] Created Meta Business Manager account
- [ ] Verified Twilio phone number
- [ ] Updated ENVIRONMENT=production in .env

### Real Health Worker Registration
- [ ] Shared registration_portal.html with 5 health workers
- [ ] Each verified themselves
- [ ] All showing "verified" status in MongoDB

### Production Broadcast
```bash
curl -X POST http://localhost:8000/api/alerts/broadcast \
  -H "Content-Type: application/json" \
  -d '{
    "city": "Kathmandu",
    "aqi_value": 380,
    "aqi_level": "HIGH",
    "recipient_type": "health_worker"
  }'
```

Check for:
- [ ] All 5 health workers receive SMS
- [ ] All 5 receive WhatsApp (direct, no sandbox)
- [ ] All 5 receive email
- [ ] Analytics show 5 × 3 = 15 total messages

---

## Final Verification Checklist

### All Components Working
- [ ] Backend API running
- [ ] MongoDB connected
- [ ] Twilio SMS working
- [ ] Twilio WhatsApp (Sandbox) working
- [ ] Resend Email working
- [ ] Registration form submitting
- [ ] Verification code system working
- [ ] Single notification sending working
- [ ] Broadcast to multiple users working
- [ ] Analytics endpoints working
- [ ] MongoDB logging all events

### Data Integrity
- [ ] Contacts normalized (phone numbers)
- [ ] Timestamps present on all records
- [ ] Consent records logged
- [ ] Notification logs complete
- [ ] No duplicate registrations

### Performance
- [ ] SMS sends < 2 seconds
- [ ] WhatsApp sends < 5 seconds
- [ ] Email sends < 30 seconds
- [ ] Broadcast handles 100+ recipients

### Security
- [ ] Verification required before sending
- [ ] Consent checked before broadcasting
- [ ] Phone numbers in E.164 format
- [ ] API has basic validation
- [ ] No sensitive data in logs

---

## Troubleshooting Guide

### SMS Not Sending
**Error:** `401 Unauthorized`
- Check TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN
- Verify against Twilio Console

**Error:** `Invalid phone number`
- Use E.164 format: `+16175550123` (no spaces/dashes)

**Error:** `Insufficient funds`
- Check Twilio balance
- Add credit if needed

### WhatsApp Not Sending
**Error:** `[63015] User is not part of our WhatsApp`
- User hasn't joined sandbox yet
- They need to send: `join KEYWORD`

**Error:** Outside customer service window
- Only happens outside 24 hours after user message
- Use message templates for production

### Email Not Sending
**Error:** `Invalid API key`
- Check RESEND_API_KEY starts with `re_`
- Copy from Resend Dashboard again

**Error:** `Invalid email address`
- Check recipient email is valid
- Test with your own email first

### MongoDB Not Connecting
**Error:** `connect ECONNREFUSED`
- Check DATABASE_URL is correct
- Add your IP to MongoDB Network Access
- Use "Allow from Anywhere" while testing

**Error:** `MongoServerSelectionError`
- Check connection string for typos
- Verify password doesn't have special characters
- Try resetting password in MongoDB Atlas

---

## Success Criteria

You're ready for production when:

✅ **Week 1 Complete:**
- [ ] You can register yourself
- [ ] You can verify yourself
- [ ] You receive SMS test alert
- [ ] You receive WhatsApp test alert
- [ ] You receive email test alert
- [ ] All data logged to MongoDB
- [ ] Analytics show correct counts

✅ **Week 2 Complete:**
- [ ] 5+ real health workers registered
- [ ] All verified
- [ ] Broadcast alert reaches all
- [ ] They can reply via SMS
- [ ] Replies logged to inbound_messages
- [ ] No failed deliveries

✅ **Ready to Deploy:**
- [ ] Move to Render.com (see RENDER_DEPLOYMENT_GUIDE.md)
- [ ] Update ENVIRONMENT=production
- [ ] Configure Twilio webhooks to Render URL
- [ ] Test end-to-end on production

---

## Keep Testing

Even after launch, test:
- [ ] Weekly: Send test alert
- [ ] Monthly: Verify all contacts still active
- [ ] Monthly: Check MongoDB storage usage
- [ ] Monthly: Review failed message logs
- [ ] Quarterly: Load test with 100+ simultaneous users

**Once you pass all tests: You're ready to save lives! 🚀**
