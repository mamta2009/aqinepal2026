"""
Early Warning System - Complete Notification Module
Features:
- Twilio SMS (Sandbox + Production)
- Twilio WhatsApp (Sandbox + Production)
- Resend Email Integration
- Health Worker Registration with Consent
- Multi-channel Alert Broadcasting
- Webhook handlers for inbound messages
"""

import os
import json
from datetime import datetime, timedelta
from typing import Optional, List
from enum import Enum

from fastapi import FastAPI, HTTPException, BackgroundTasks, Request
from pydantic import BaseModel, EmailStr
from motor.motor_asyncio import AsyncMotorClient, AsyncMotorDatabase
from twilio.rest import Client as TwilioClient
from twilio.base.exceptions import TwilioRestException
import httpx

# ============================================
# CONFIGURATION & INITIALIZATION
# ============================================

app = FastAPI(title="Early Warning Notifications API")

# Database
DATABASE_URL = os.getenv("DATABASE_URL")
db: AsyncMotorDatabase = None

async def connect_to_mongo():
    global db
    client = AsyncMotorClient(DATABASE_URL)
    db = client.early_warning
    print("✅ Connected to MongoDB")

async def close_mongo_connection():
    await AsyncMotorClient(DATABASE_URL).close()

app.add_event_handler("startup", connect_to_mongo)
app.add_event_handler("shutdown", close_mongo_connection)

# Twilio Configuration
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")  # +1-617-XXX-XXXX
TWILIO_WHATSAPP_SANDBOX = os.getenv("TWILIO_WHATSAPP_SANDBOX", "+14155238886")

twilio_client = TwilioClient(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# Resend Configuration
RESEND_API_KEY = os.getenv("RESEND_API_KEY")
RESEND_API_URL = "https://api.resend.com/emails"
RESEND_FROM_EMAIL = os.getenv("RESEND_FROM_EMAIL", "alerts@early-warning.com")

# Environment
ENVIRONMENT = os.getenv("ENVIRONMENT", "sandbox")  # "sandbox" or "production"

# ============================================
# DATA MODELS
# ============================================

class ContactType(str, Enum):
    HEALTH_WORKER = "health_worker"
    PARENT = "parent"
    ADMIN = "admin"
    GOVERNMENT = "government"

class NotificationChannel(str, Enum):
    SMS = "sms"
    WHATSAPP = "whatsapp"
    EMAIL = "email"

class AlertLevel(str, Enum):
    LOW = "LOW"
    MODERATE = "MODERATE"
    HIGH = "HIGH"
    SEVERE = "SEVERE"

class ContactRegistration(BaseModel):
    """Health worker or parent registration"""
    name: str
    email: EmailStr
    phone_number: str  # +1-617-555-0123
    whatsapp_number: Optional[str] = None
    contact_type: ContactType
    facility_id: Optional[str] = None
    facility_name: Optional[str] = None
    preferred_channels: List[NotificationChannel]
    language: str = "en"  # "en", "ne" for Nepali, etc.
    consent_given: bool = False
    consent_timestamp: Optional[datetime] = None

class NotificationRequest(BaseModel):
    """Send single notification"""
    recipient_id: str  # MongoDB ObjectId
    channel: NotificationChannel
    subject: Optional[str] = None
    message: str
    alert_level: Optional[AlertLevel] = None

class AlertBroadcast(BaseModel):
    """Broadcast alert to multiple recipients"""
    city: str
    aqi_value: int
    aqi_level: AlertLevel
    recipient_type: ContactType = ContactType.HEALTH_WORKER  # "all" broadcasts to everyone
    message_override: Optional[str] = None

class ConsentUpdate(BaseModel):
    """Update consent preferences"""
    contact_id: str
    consent_given: bool
    preferred_channels: List[NotificationChannel]

# ============================================
# MONGODB COLLECTIONS & INDEXES
# ============================================

async def setup_database():
    """Create collections and indexes"""
    try:
        # Health worker/parent contacts collection
        await db.contacts.create_index("email", unique=True)
        await db.contacts.create_index("phone_number")
        await db.contacts.create_index("whatsapp_number")
        await db.contacts.create_index("facility_id")
        
        # Notification logs
        await db.notification_logs.create_index("recipient_id")
        await db.notification_logs.create_index("timestamp")
        await db.notification_logs.create_index("status")
        
        # Inbound messages
        await db.inbound_messages.create_index("from_number")
        await db.inbound_messages.create_index("timestamp")
        
        # Consent records
        await db.consent_records.create_index("contact_id")
        await db.consent_records.create_index("timestamp")
        
        # Alert history
        await db.alert_history.create_index("city")
        await db.alert_history.create_index("timestamp")
        
        print("✅ Database indexes created")
    except Exception as e:
        print(f"⚠️ Index creation: {e}")

# ============================================
# CONTACT REGISTRATION ENDPOINTS
# ============================================

@app.post("/api/contacts/register")
async def register_contact(contact: ContactRegistration):
    """
    Register health worker or parent for alerts
    
    Example:
    {
        "name": "Dr. Sharma",
        "email": "sharma@hospital.com",
        "phone_number": "+1-617-555-0123",
        "whatsapp_number": "+1-617-555-0123",
        "contact_type": "health_worker",
        "facility_name": "Kathmandu Medical Center",
        "preferred_channels": ["sms", "whatsapp", "email"],
        "language": "en",
        "consent_given": true
    }
    """
    
    # Validate phone numbers
    if not contact.phone_number.startswith("+"):
        raise HTTPException(status_code=400, detail="Phone must start with +")
    
    normalized_phone = contact.phone_number.replace(" ", "").replace("-", "")
    normalized_whatsapp = contact.whatsapp_number.replace(" ", "").replace("-", "") if contact.whatsapp_number else normalized_phone
    
    # Check if email already registered
    existing = await db.contacts.find_one({"email": contact.email})
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")
    
    # Create contact document
    contact_doc = {
        "name": contact.name,
        "email": contact.email,
        "phone_number": normalized_phone,
        "whatsapp_number": normalized_whatsapp,
        "contact_type": contact.contact_type.value,
        "facility_id": contact.facility_id,
        "facility_name": contact.facility_name,
        "preferred_channels": [ch.value for ch in contact.preferred_channels],
        "language": contact.language,
        "consent_given": contact.consent_given,
        "consent_timestamp": contact.consent_timestamp or datetime.utcnow(),
        "created_at": datetime.utcnow(),
        "active": True,
        "verification_status": "pending",  # Verify via SMS or email
        "verification_code": None,
        "verified_at": None,
    }
    
    result = await db.contacts.insert_one(contact_doc)
    contact_id = str(result.inserted_id)
    
    # Log consent
    await db.consent_records.insert_one({
        "contact_id": contact_id,
        "contact_email": contact.email,
        "consent_given": contact.consent_given,
        "channels": [ch.value for ch in contact.preferred_channels],
        "timestamp": datetime.utcnow()
    })
    
    # Send verification email
    if "email" in [ch.value for ch in contact.preferred_channels]:
        await send_verification_email(contact_id, contact.email, contact.name)
    
    # Send verification SMS
    if "sms" in [ch.value for ch in contact.preferred_channels]:
        await send_verification_sms(contact_id, normalized_phone)
    
    return {
        "success": True,
        "contact_id": contact_id,
        "message": "Contact registered successfully",
        "channels": [ch.value for ch in contact.preferred_channels],
        "next_step": "Check email/SMS for verification code"
    }


@app.post("/api/contacts/verify")
async def verify_contact(contact_id: str, verification_code: str):
    """Verify contact via email or SMS code"""
    
    contact = await db.contacts.find_one({"_id": contact_id})
    if not contact:
        raise HTTPException(status_code=404, detail="Contact not found")
    
    # This is simplified - in production, hash and compare verification codes
    if contact.get("verification_code") == verification_code:
        await db.contacts.update_one(
            {"_id": contact_id},
            {
                "$set": {
                    "verification_status": "verified",
                    "verified_at": datetime.utcnow()
                }
            }
        )
        return {"success": True, "message": "Contact verified successfully"}
    
    raise HTTPException(status_code=400, detail="Invalid verification code")


@app.get("/api/contacts/{contact_id}")
async def get_contact(contact_id: str):
    """Get contact details"""
    from bson import ObjectId
    
    try:
        contact = await db.contacts.find_one({"_id": ObjectId(contact_id)})
        if not contact:
            raise HTTPException(status_code=404, detail="Contact not found")
        
        # Remove sensitive fields
        contact.pop("verification_code", None)
        contact["_id"] = str(contact["_id"])
        
        return contact
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/contacts")
async def list_contacts(facility_id: Optional[str] = None, contact_type: Optional[str] = None):
    """List all registered contacts with optional filtering"""
    
    query = {"active": True}
    if facility_id:
        query["facility_id"] = facility_id
    if contact_type:
        query["contact_type"] = contact_type
    
    contacts = await db.contacts.find(query).to_list(length=1000)
    
    for contact in contacts:
        contact["_id"] = str(contact["_id"])
        contact.pop("verification_code", None)
    
    return contacts


@app.put("/api/contacts/{contact_id}/preferences")
async def update_preferences(contact_id: str, update: ConsentUpdate):
    """Update contact notification preferences"""
    from bson import ObjectId
    
    try:
        result = await db.contacts.update_one(
            {"_id": ObjectId(contact_id)},
            {
                "$set": {
                    "preferred_channels": [ch.value for ch in update.preferred_channels],
                    "consent_given": update.consent_given,
                    "updated_at": datetime.utcnow()
                }
            }
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Contact not found")
        
        # Log consent change
        await db.consent_records.insert_one({
            "contact_id": contact_id,
            "consent_given": update.consent_given,
            "channels": [ch.value for ch in update.preferred_channels],
            "timestamp": datetime.utcnow()
        })
        
        return {"success": True, "message": "Preferences updated"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ============================================
# VERIFICATION EMAIL & SMS
# ============================================

async def send_verification_email(contact_id: str, email: str, name: str):
    """Send verification email via Resend"""
    
    verification_code = "123456"  # Generate random code in production
    
    # Update contact with verification code
    await db.contacts.update_one(
        {"_id": contact_id},
        {"$set": {"verification_code": verification_code}}
    )
    
    html_content = f"""
    <h2>Welcome to Early Warning System</h2>
    <p>Hi {name},</p>
    <p>Thank you for registering to receive air quality alerts.</p>
    <p><strong>Your verification code:</strong></p>
    <h1 style="font-size: 32px; letter-spacing: 5px;">{verification_code}</h1>
    <p>Click here to verify: <a href="https://your-app.com/verify?code={verification_code}">Verify Now</a></p>
    <p style="color: #666; font-size: 12px;">This code expires in 24 hours.</p>
    """
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                RESEND_API_URL,
                headers={"Authorization": f"Bearer {RESEND_API_KEY}"},
                json={
                    "from": RESEND_FROM_EMAIL,
                    "to": email,
                    "subject": "Verify Your Early Warning System Account",
                    "html": html_content
                }
            )
        
        if response.status_code == 200:
            await db.notification_logs.insert_one({
                "recipient_id": str(contact_id),
                "channel": "email",
                "recipient": email,
                "type": "verification",
                "status": "sent",
                "timestamp": datetime.utcnow()
            })
            return {"success": True}
        else:
            print(f"Resend error: {response.text}")
            raise Exception("Failed to send email")
    
    except Exception as e:
        print(f"Email verification failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to send verification email")


async def send_verification_sms(contact_id: str, phone_number: str):
    """Send verification SMS via Twilio"""
    
    verification_code = "123456"  # Generate random code in production
    
    await db.contacts.update_one(
        {"_id": contact_id},
        {"$set": {"verification_code": verification_code}}
    )
    
    message_text = f"Your Early Warning verification code is: {verification_code}. Valid for 24 hours."
    
    try:
        msg = twilio_client.messages.create(
            body=message_text,
            from_=TWILIO_PHONE_NUMBER,
            to=phone_number
        )
        
        await db.notification_logs.insert_one({
            "recipient_id": str(contact_id),
            "channel": "sms",
            "recipient": phone_number,
            "type": "verification",
            "status": "sent",
            "twilio_sid": msg.sid,
            "timestamp": datetime.utcnow()
        })
        
        return {"success": True}
    except TwilioRestException as e:
        print(f"SMS verification failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to send verification SMS")


# ============================================
# TWILIO SANDBOX SETUP ENDPOINT
# ============================================

@app.get("/api/notifications/whatsapp/sandbox-info")
async def get_sandbox_info():
    """Get Twilio WhatsApp Sandbox setup instructions"""
    
    return {
        "sandbox_number": TWILIO_WHATSAPP_SANDBOX,
        "setup_instructions": {
            "step_1": "Save this number in your phone: " + TWILIO_WHATSAPP_SANDBOX,
            "step_2": "Send WhatsApp message: 'join your-sandbox-keyword'",
            "step_3": "You should receive confirmation message",
            "step_4": "You're now registered to receive test alerts"
        },
        "cost": "FREE (Sandbox only)",
        "limit": "50 messages/day on free Twilio account",
        "note": "Sandbox is for testing only. Switch to production after verification."
    }


# ============================================
# NOTIFICATION SENDING
# ============================================

async def send_sms(phone_number: str, message: str) -> dict:
    """Send SMS via Twilio"""
    try:
        msg = twilio_client.messages.create(
            body=message,
            from_=TWILIO_PHONE_NUMBER,
            to=phone_number
        )
        return {"success": True, "sid": msg.sid, "status": "sent"}
    except TwilioRestException as e:
        print(f"SMS failed: {e}")
        return {"success": False, "error": str(e), "status": "failed"}


async def send_whatsapp(whatsapp_number: str, message: str, use_sandbox: bool = False) -> dict:
    """Send WhatsApp message via Twilio"""
    
    from_number = TWILIO_WHATSAPP_SANDBOX if use_sandbox else TWILIO_PHONE_NUMBER
    
    try:
        msg = twilio_client.messages.create(
            body=message,
            from_=f"whatsapp:{from_number}",
            to=f"whatsapp:{whatsapp_number}"
        )
        return {"success": True, "sid": msg.sid, "status": "sent"}
    except TwilioRestException as e:
        print(f"WhatsApp failed: {e}")
        return {"success": False, "error": str(e), "status": "failed"}


async def send_email(to_email: str, subject: str, html_content: str) -> dict:
    """Send email via Resend"""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                RESEND_API_URL,
                headers={"Authorization": f"Bearer {RESEND_API_KEY}"},
                json={
                    "from": RESEND_FROM_EMAIL,
                    "to": to_email,
                    "subject": subject,
                    "html": html_content
                }
            )
        
        if response.status_code == 200:
            return {"success": True, "status": "sent"}
        else:
            return {"success": False, "error": response.text, "status": "failed"}
    
    except Exception as e:
        print(f"Email failed: {e}")
        return {"success": False, "error": str(e), "status": "failed"}


# ============================================
# SINGLE NOTIFICATION ENDPOINT
# ============================================

@app.post("/api/notifications/send")
async def send_notification(request: NotificationRequest):
    """Send single notification to recipient"""
    from bson import ObjectId
    
    # Get recipient
    try:
        recipient = await db.contacts.find_one({"_id": ObjectId(request.recipient_id)})
    except:
        raise HTTPException(status_code=404, detail="Contact not found")
    
    if not recipient:
        raise HTTPException(status_code=404, detail="Contact not found")
    
    if not recipient.get("consent_given"):
        raise HTTPException(status_code=403, detail="Contact has not given consent")
    
    result = None
    
    # Send based on channel
    if request.channel == NotificationChannel.SMS:
        result = await send_sms(recipient["phone_number"], request.message)
    
    elif request.channel == NotificationChannel.WHATSAPP:
        use_sandbox = ENVIRONMENT == "sandbox"
        result = await send_whatsapp(
            recipient["whatsapp_number"],
            request.message,
            use_sandbox=use_sandbox
        )
    
    elif request.channel == NotificationChannel.EMAIL:
        html_content = f"<p>{request.message}</p>"
        result = await send_email(
            recipient["email"],
            request.subject or "Early Warning Alert",
            html_content
        )
    
    # Log notification
    log_entry = {
        "recipient_id": request.recipient_id,
        "recipient_email": recipient["email"],
        "recipient_name": recipient["name"],
        "channel": request.channel.value,
        "message": request.message,
        "alert_level": request.alert_level.value if request.alert_level else None,
        "status": result["status"],
        "twilio_sid": result.get("sid"),
        "error": result.get("error"),
        "timestamp": datetime.utcnow()
    }
    
    await db.notification_logs.insert_one(log_entry)
    
    return {
        "success": result["success"],
        "channel": request.channel.value,
        "recipient": recipient["name"],
        "status": result["status"]
    }


# ============================================
# BULK ALERT BROADCAST
# ============================================

@app.post("/api/alerts/broadcast")
async def broadcast_alert(alert: AlertBroadcast, background_tasks: BackgroundTasks):
    """
    Broadcast alert to all registered health workers via multiple channels
    
    Example:
    {
        "city": "Kathmandu",
        "aqi_value": 450,
        "aqi_level": "SEVERE",
        "recipient_type": "health_worker"
    }
    """
    
    # Get emoji and color based on AQI level
    emoji_map = {
        "LOW": "🟢",
        "MODERATE": "🟡",
        "HIGH": "🔴",
        "SEVERE": "🔴🔴"
    }
    
    emoji = emoji_map.get(alert.aqi_level.value, "⚠️")
    
    # Build message
    message = alert.message_override or f"""{emoji} AIR QUALITY ALERT

🏙️ Location: {alert.city}
📊 AQI Level: {alert.aqi_level.value}
🔢 AQI Value: {alert.aqi_value}

📋 Recommended Actions:
• Check facility oxygen stock
• Alert respiratory unit staff
• Prepare for increased admissions
• Log all responses in system

⏰ Update: Every 6 hours
🔗 Dashboard: https://your-app.com/dashboard

Questions? Contact support@early-warning.com"""
    
    # Get recipients
    query = {
        "active": True,
        "consent_given": True,
        "verification_status": "verified"
    }
    
    if alert.recipient_type != "all":
        query["contact_type"] = alert.recipient_type.value
    
    recipients = await db.contacts.find(query).to_list(length=5000)
    
    # Send in background
    background_tasks.add_task(
        broadcast_to_recipients,
        recipients,
        message,
        alert.aqi_level.value,
        alert.city
    )
    
    return {
        "success": True,
        "alert_id": datetime.utcnow().isoformat(),
        "recipients_count": len(recipients),
        "city": alert.city,
        "aqi_level": alert.aqi_level.value,
        "message": "Alert broadcast initiated. Sending in background..."
    }


async def broadcast_to_recipients(recipients: list, message: str, aqi_level: str, city: str):
    """Background task to send alerts to multiple recipients"""
    
    results = {
        "sms": {"sent": 0, "failed": 0},
        "whatsapp": {"sent": 0, "failed": 0},
        "email": {"sent": 0, "failed": 0}
    }
    
    for recipient in recipients:
        # Send via each preferred channel
        for channel in recipient.get("preferred_channels", []):
            result = None
            
            if channel == "sms":
                result = await send_sms(recipient["phone_number"], message)
                results["sms"]["sent" if result["success"] else "failed"] += 1
            
            elif channel == "whatsapp":
                use_sandbox = ENVIRONMENT == "sandbox"
                result = await send_whatsapp(
                    recipient["whatsapp_number"],
                    message,
                    use_sandbox=use_sandbox
                )
                results["whatsapp"]["sent" if result["success"] else "failed"] += 1
            
            elif channel == "email":
                result = await send_email(
                    recipient["email"],
                    f"AIR QUALITY ALERT - {aqi_level}",
                    f"<h2>{city} - {aqi_level}</h2><p>{message}</p>"
                )
                results["email"]["sent" if result["success"] else "failed"] += 1
            
            # Log each notification
            if result:
                await db.notification_logs.insert_one({
                    "recipient_id": str(recipient.get("_id")),
                    "recipient_email": recipient["email"],
                    "recipient_name": recipient["name"],
                    "channel": channel,
                    "alert_level": aqi_level,
                    "city": city,
                    "status": result["status"],
                    "timestamp": datetime.utcnow()
                })
    
    # Log broadcast summary
    await db.alert_broadcasts.insert_one({
        "city": city,
        "aqi_level": aqi_level,
        "timestamp": datetime.utcnow(),
        "results": results,
        "total_recipients": len(recipients)
    })
    
    print(f"✅ Alert broadcast complete: {results}")


# ============================================
# WEBHOOK HANDLERS (Inbound Messages)
# ============================================

@app.post("/api/webhooks/sms")
async def handle_sms_webhook(request: Request):
    """Handle inbound SMS from Twilio"""
    
    form_data = await request.form()
    from_number = form_data.get("From")
    message_body = form_data.get("Body")
    message_sid = form_data.get("MessageSid")
    
    # Store in database
    await db.inbound_messages.insert_one({
        "type": "sms",
        "from": from_number,
        "body": message_body,
        "twilio_sid": message_sid,
        "timestamp": datetime.utcnow()
    })
    
    # Update contact's last message time
    await db.contacts.update_one(
        {"phone_number": from_number},
        {"$set": {"last_inbound_at": datetime.utcnow()}}
    )
    
    # Send auto-reply
    twilio_client.messages.create(
        body="Thank you for your message. We received it. We'll respond shortly.",
        from_=TWILIO_PHONE_NUMBER,
        to=from_number
    )
    
    return {"success": True}


@app.post("/api/webhooks/whatsapp")
async def handle_whatsapp_webhook(request: Request):
    """Handle inbound WhatsApp from Twilio"""
    
    form_data = await request.form()
    from_number = form_data.get("From")  # whatsapp:+1617555XXXX
    message_body = form_data.get("Body")
    message_sid = form_data.get("MessageSid")
    
    # Extract phone from whatsapp: format
    clean_phone = from_number.replace("whatsapp:", "") if "whatsapp:" in from_number else from_number
    
    # Store in database
    await db.inbound_messages.insert_one({
        "type": "whatsapp",
        "from": clean_phone,
        "body": message_body,
        "twilio_sid": message_sid,
        "timestamp": datetime.utcnow()
    })
    
    # Update contact
    await db.contacts.update_one(
        {"whatsapp_number": clean_phone},
        {"$set": {"last_inbound_at": datetime.utcnow()}}
    )
    
    # Send auto-reply
    twilio_client.messages.create(
        body="Thank you for your WhatsApp message. We received it. 🙏",
        from_=f"whatsapp:{TWILIO_PHONE_NUMBER}",
        to=from_number
    )
    
    return {"success": True}


@app.post("/api/webhooks/message-status")
async def handle_message_status(request: Request):
    """Handle Twilio message status updates"""
    
    form_data = await request.form()
    message_sid = form_data.get("MessageSid")
    message_status = form_data.get("MessageStatus")  # delivered, failed, etc.
    
    # Update notification log
    await db.notification_logs.update_one(
        {"twilio_sid": message_sid},
        {"$set": {"delivery_status": message_status}}
    )
    
    return {"success": True}


# ============================================
# ANALYTICS & REPORTING
# ============================================

@app.get("/api/analytics/notifications")
async def get_notification_analytics(days: int = 7):
    """Get notification delivery analytics"""
    
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Count by channel
    pipeline = [
        {"$match": {"timestamp": {"$gte": start_date}}},
        {"$group": {
            "_id": "$channel",
            "total": {"$sum": 1},
            "success": {"$sum": {"$cond": [{"$eq": ["$status", "sent"]}, 1, 0]}}
        }}
    ]
    
    channel_stats = await db.notification_logs.aggregate(pipeline).to_list(None)
    
    # Count by alert level
    pipeline = [
        {"$match": {"timestamp": {"$gte": start_date}, "alert_level": {"$exists": True}}},
        {"$group": {
            "_id": "$alert_level",
            "count": {"$sum": 1}
        }}
    ]
    
    alert_stats = await db.notification_logs.aggregate(pipeline).to_list(None)
    
    return {
        "period_days": days,
        "by_channel": channel_stats,
        "by_alert_level": alert_stats,
        "timestamp": datetime.utcnow()
    }


@app.get("/api/analytics/contacts")
async def get_contact_analytics():
    """Get contact registration analytics"""
    
    total = await db.contacts.count_documents({})
    verified = await db.contacts.count_documents({"verification_status": "verified"})
    
    by_type = await db.contacts.aggregate([
        {"$group": {"_id": "$contact_type", "count": {"$sum": 1}}}
    ]).to_list(None)
    
    by_channel = await db.contacts.aggregate([
        {"$unwind": "$preferred_channels"},
        {"$group": {"_id": "$preferred_channels", "count": {"$sum": 1}}}
    ]).to_list(None)
    
    return {
        "total_contacts": total,
        "verified_contacts": verified,
        "verification_rate": f"{(verified/total*100):.1f}%" if total > 0 else "0%",
        "by_type": by_type,
        "by_channel": by_channel
    }


# ============================================
# HEALTH CHECK
# ============================================

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Early Warning Notifications API",
        "environment": ENVIRONMENT,
        "timestamp": datetime.utcnow()
    }


# ============================================
# STARTUP
# ============================================

@app.on_event("startup")
async def startup_event():
    """Setup on startup"""
    await setup_database()
    print(f"✅ Notification API started in {ENVIRONMENT} mode")
    print(f"📱 Twilio Phone: {TWILIO_PHONE_NUMBER}")
    print(f"💬 WhatsApp Sandbox: {TWILIO_WHATSAPP_SANDBOX}")
    print(f"📧 Resend Email: {RESEND_FROM_EMAIL}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
