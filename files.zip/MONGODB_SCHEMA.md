# MongoDB Schema - Early Warning System

All collections are in the `early_warning` database.

---

## 1. air_quality

Real-time air quality readings from AQICN (Nepal monitoring stations).

```javascript
{
  _id: ObjectId,
  city: "Kathmandu",
  aqi: 165,
  aqi_level: "UNHEALTHY",
  pm25: 95.2,
  pm10: 145.3,
  o3: 12.5,
  no2: 25.8,
  so2: 8.3,
  co: 1200.5,
  timestamp: "2024-01-20T14:30:00Z",
  source: "aqicn",
  station_id: "H14868"
}
```

**Indexes:**
- `city` (unique) - Fast city lookups
- `timestamp` - Time-based queries
- `station_id` - Sync tracking

**Update frequency:** Every 6 hours (via background job)

**Data retention:** Forever (compress to archive after 1 year)

---

## 2. contacts

Registered health workers, parents, administrators.

```javascript
{
  _id: ObjectId,
  name: "Dr. Ram Paudel",
  email: "ram@hospital.example.com",
  phone_number: "+97712345678",
  whatsapp_number: "+97712345678",
  contact_type: "health_worker",  // or "parent", "admin"
  facility_name: "Kathmandu Medical Center",
  facility_id: "kmh_001",
  preferred_channels: ["sms", "whatsapp", "email"],
  language: "en",  // or "ne"
  verification_status: "verified",  // or "pending", "unverified"
  verification_code: "123456",  // Expires after 1 hour
  consent_given: true,
  active: true,
  created_at: "2024-01-15T10:00:00Z",
  verified_at: "2024-01-15T10:05:00Z",
  last_alert_at: "2024-01-20T14:30:00Z"
}
```

**Indexes:**
- `email` (unique) - Check for duplicates
- `phone_number` - SMS lookups
- `facility_id` - Facility-level queries
- `verification_status` - Filter verified contacts

**Growth projection:** 100-1000 contacts in 6 months

---

## 3. alerts

Alert history (triggered when AQI exceeds threshold).

```javascript
{
  _id: ObjectId,
  city: "Kathmandu",
  aqi_value: 165,
  aqi_level: "UNHEALTHY",
  recipient_type: "health_worker",
  recipient_count: 45,
  message: "🔴 UNHEALTHY air quality in Kathmandu\nAQI: 165\nCheck facility oxygen stock",
  status: "sent",  // or "pending", "failed"
  timestamp: "2024-01-20T14:30:00Z",
  triggered_at: "2024-01-20T14:30:15Z"
}
```

**Indexes:**
- `city` - City-level analytics
- `timestamp` - Time-based queries
- `aqi_level` - Filter by severity

**Growth projection:** 10-50 alerts per day

---

## 4. notification_logs

Log of every SMS/WhatsApp/Email sent.

```javascript
{
  _id: ObjectId,
  recipient_id: ObjectId,  // Reference to contacts._id
  recipient_email: "ram@hospital.example.com",
  channel: "sms",  // or "whatsapp", "email"
  message: "🔴 UNHEALTHY air quality...",
  status: "sent",  // or "failed", "queued", "delivered"
  error: null,  // Only if status is "failed"
  timestamp: "2024-01-20T14:30:00Z",
  delivery_time_ms: 245,
  external_id: "SMfbff4b1234567890"  // Twilio/Resend message ID
}
```

**Indexes:**
- `recipient_id` - Per-contact history
- `timestamp` - Time-range queries
- `status` - Success/failure breakdown
- TTL on `timestamp` (delete after 90 days)

**Growth projection:** 100-500 notifications per day

---

## 5. action_logs

Actions taken by facilities in response to alerts.

```javascript
{
  _id: ObjectId,
  facility_id: "kmh_001",
  facility_name: "Kathmandu Medical Center",
  action_type: "stocked_oxygen",  // Custom types per protocol
  details: "Received 50 oxygen cylinders from Ministry of Health",
  timestamp: "2024-01-20T15:00:00Z",
  response_time_hours: 0.5,  // How long after alert
  contact_id: ObjectId,  // Who logged the action
  location: {
    lat: 27.7172,
    lng: 85.3240
  }
}
```

**Indexes:**
- `facility_id` - Per-facility analytics
- `timestamp` - Timeline view
- `action_type` - Response pattern analysis

**Growth projection:** 20-100 actions per day

---

## 6. consent_records

Audit trail of consent & privacy.

```javascript
{
  _id: ObjectId,
  contact_id: ObjectId,
  email: "ram@hospital.example.com",
  phone_number: "+97712345678",
  consent_given: true,
  consent_type: "health_alerts",  // or "research", "data_sharing"
  privacy_version: "v1",
  language: "en",
  ip_address: "192.168.1.1",
  timestamp: "2024-01-15T10:00:00Z"
}
```

**Purpose:** UNICEF compliance, show consent was explicit

**Indexes:**
- `contact_id` - Full consent history per person
- `timestamp` - Audit trail by date

---

## 7. facilities

Health facility registry.

```javascript
{
  _id: ObjectId,
  facility_id: "kmh_001",
  name: "Kathmandu Medical Center",
  type: "hospital",  // or "clinic", "health_post"
  district: "Kathmandu",
  province: "Bagmati",
  location: {
    lat: 27.7172,
    lng: 85.3240,
    address: "Kathmandu, Nepal"
  },
  contact_person: "Dr. Ram Paudel",
  phone: "+97712345678",
  email: "info@kmh.com",
  staff_count: 50,
  beds: 100,
  has_oxygen: true,
  has_ventilators: 5,
  created_at: "2024-01-01T00:00:00Z",
  updated_at: "2024-01-20T14:30:00Z"
}
```

**Indexes:**
- `facility_id` (unique) - Fast lookup
- `district` - Geographic queries
- `province` - Regional reports

**Synced from:** DHIS2 (once per week)

---

## 8. respiratory_cases

Daily case counts reported by facilities.

```javascript
{
  _id: ObjectId,
  facility_id: "kmh_001",
  date: "2024-01-20",
  new_cases: 25,
  severe_cases: 5,
  oxygen_required: 3,
  ventilator_required: 1,
  discharges: 12,
  deaths: 0,
  aqi_that_day: 165,
  weather_temp: 18,
  weather_humidity: 45,
  timestamp: "2024-01-20T23:00:00Z"
}
```

**Indexes:**
- `facility_id, date` (compound) - Fast daily lookups
- `date` - Trend analysis across all facilities
- `aqi_that_day` - Correlation with air quality

**Growth projection:** 5-10 entries per facility per day

---

## 9. weather_forecast

5-day weather forecasts (for correlation analysis).

```javascript
{
  _id: ObjectId,
  city: "Kathmandu",
  forecast_date: "2024-01-21",
  temperature_high: 20,
  temperature_low: 8,
  humidity: 65,
  wind_speed: 12,
  rainfall: 0,
  cloud_cover: 40,
  uv_index: 4,
  source: "openweather",
  timestamp: "2024-01-20T12:00:00Z"
}
```

**Indexes:**
- `city, forecast_date`
- `timestamp`

---

## 10. inbound_messages

SMS/WhatsApp messages received from health workers.

```javascript
{
  _id: ObjectId,
  type: "sms",  // or "whatsapp"
  from: "+97712345678",
  body: "We stocked oxygen today",
  contact_id: ObjectId,
  sentiment: "positive",  // Optional: AI analysis
  keywords: ["oxygen", "stocked"],
  twilio_sid: "SMfbff4b1234567890",
  timestamp: "2024-01-20T15:30:00Z"
}
```

**Indexes:**
- `from` - Track conversations with each sender
- `timestamp` - Recent messages
- TTL on `timestamp` (delete after 30 days)

---

## Sample Queries

### Get current air quality for all cities

```javascript
db.air_quality.find({})
```

### Get verified health workers in Kathmandu

```javascript
db.contacts.find({
  verification_status: "verified",
  facility_id: /kathmandu/i,
  active: true
})
```

### Find alerts in last 7 days

```javascript
db.alerts.find({
  timestamp: {
    $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
  }
}).sort({ timestamp: -1 })
```

### Get facility action response times

```javascript
db.action_logs.aggregate([
  {
    $match: {
      facility_id: "kmh_001",
      timestamp: {
        $gte: new Date("2024-01-01"),
        $lt: new Date("2024-02-01")
      }
    }
  },
  {
    $group: {
      _id: "$action_type",
      count: { $sum: 1 },
      avg_response_time: { $avg: "$response_time_hours" }
    }
  }
])
```

### Correlate AQI with respiratory cases

```javascript
db.respiratory_cases.aggregate([
  {
    $match: {
      date: { $gte: "2024-01-01" }
    }
  },
  {
    $group: {
      _id: null,
      avg_cases: { $avg: "$new_cases" },
      avg_aqi: { $avg: "$aqi_that_day" },
      correlation: { /* use external tool */ }
    }
  }
])
```

### Get SMS delivery success rate (last 30 days)

```javascript
db.notification_logs.aggregate([
  {
    $match: {
      channel: "sms",
      timestamp: {
        $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      }
    }
  },
  {
    $group: {
      _id: "$status",
      count: { $sum: 1 }
    }
  }
])
```

---

## Data Storage Estimates

| Collection | Docs/Month | Size/Doc | Total/Month | 6-Month Total |
|-----------|-----------|----------|-----------|--------------|
| air_quality | 180 | 1KB | 180KB | 1MB |
| contacts | 50 | 2KB | 100KB | 500KB |
| alerts | 300 | 1KB | 300KB | 1.8MB |
| notification_logs | 10,000 | 500B | 5MB | 30MB |
| action_logs | 2,000 | 1KB | 2MB | 12MB |
| respiratory_cases | 5,000 | 1KB | 5MB | 30MB |
| consent_records | 50 | 1KB | 50KB | 300KB |
| weather_forecast | 300 | 1KB | 300KB | 1.8MB |
| Others | - | - | - | 1MB |
| **TOTAL** | | | **13MB/month** | **~80MB/6mo** |

**Free tier:** 512MB
**Usage:** ~16% of free tier
**Upgrade:** Not needed for 6-month pilot

---

## Backup Strategy

MongoDB Atlas free tier includes:
- ✅ Automatic daily backups (35-day retention)
- ✅ Point-in-time recovery
- ✅ No manual intervention needed

For UNICEF submission:
- ✅ Backup verified: https://cloud.mongodb.com → Backup tab
- ✅ Test restore: Create test cluster from backup
- ✅ Document process in DEPLOYMENT.md

---

## Data Privacy & Security

**What we store:**
- Contact info (name, email, phone)
- Facility data (name, location, staff count)
- Case counts (aggregated, no patient names)
- Air quality (public data)

**What we DON'T store:**
- ❌ Patient medical records
- ❌ Identifiable health data
- ❌ Passwords (use API keys instead)

**Access Control:**
- ✅ MongoDB user has DB-level permissions only
- ✅ .env file never committed to Git
- ✅ HTTPS required (Render enforces)
- ✅ Consent records audit trail

---

## Schema Evolution

As your system grows:

**Month 2:** Add `district` field to contacts
```javascript
db.contacts.updateMany({}, { $set: { district: "Kathmandu" } })
```

**Month 3:** Add `responsiveness_score` to facilities
```javascript
db.facilities.updateMany({}, { $set: { responsiveness_score: 0 } })
```

**Month 6:** Archive old notifications (older than 90 days)
```javascript
db.notification_logs.deleteMany({
  timestamp: { $lt: new Date(Date.now() - 90*24*60*60*1000) }
})
```

MongoDB's flexible schema means these are painless changes!

---

## Questions?

For MongoDB docs: https://docs.mongodb.com/
For schema design: https://www.mongodb.com/developer/
