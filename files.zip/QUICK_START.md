# Early Warning System - Quick Start Guide

## Overview

Complete air quality & respiratory health monitoring system built with:
- **Backend:** FastAPI (Python) - 30+ REST API endpoints
- **Frontend:** Single HTML file (no build process)
- **Database:** MongoDB Atlas (free 512MB tier)
- **Hosting:** Render.com ($7/month)

**Total deployment time:** 2 weeks part-time (~25 hours)

---

## Prerequisites

Before starting, you'll need:

1. **GitHub Account** (free at github.com)
2. **MongoDB Atlas Account** (free at mongodb.com/cloud)
3. **Render Account** (free at render.com)
4. **AQICN API Token** (free at aqicn.org/api)
5. **Python 3.11+** on your machine (python.org)
6. **Git installed** (git-scm.com)

**Total time for setup:** ~30 minutes

---

## Week 1: Get It Running Locally

### Day 1-2: MongoDB + GitHub Setup (2 hours)

#### Step 1: Create MongoDB Atlas Database

```bash
# 1. Go to: https://cloud.mongodb.com/
# 2. Sign up (free account)
# 3. Create new project → "Early Warning System"
# 4. Create cluster → Select "M0" free tier
# 5. Wait for cluster to be created (5-10 minutes)
# 6. Click "Connect"
# 7. Create database user:
#    - Username: ews_user
#    - Password: [Generate secure password]
#    - Copy to .env file below
# 8. Choose "Drivers" connection method
# 9. Copy connection string:
#    mongodb+srv://ews_user:PASSWORD@cluster.mongodb.net/early_warning?retryWrites=true&w=majority
# 10. Add your IP to whitelist (or 0.0.0.0/0 for MVP)
```

**Connection string format:**
```
mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/early_warning?retryWrites=true&w=majority
```

#### Step 2: Create GitHub Repository

```bash
# 1. Go to: https://github.com/new
# 2. Create repository: "early-warning-system"
# 3. Make it PUBLIC (so Render can deploy)
# 4. Click "Create repository"
# 5. Clone to your machine:

git clone https://github.com/YOUR_USERNAME/early-warning-system.git
cd early-warning-system
```

#### Step 3: Get AQICN Token

```
Visit: https://aqicn.org/api/
→ Click "Sign Up"
→ Fill form (no credit card needed)
→ Check email for token
→ Save token (you'll add to .env)
```

**Total: ~30 minutes**

---

### Day 3-4: Local Development Setup (2 hours)

#### Step 1: Install Python Dependencies

```bash
# Copy all files to your local repo:
# - main.py
# - requirements.txt
# - early_warning_dashboard.html
# - .env.example
# - .gitignore
# - render.yaml

# Create virtual environment (isolates Python packages)
python3 -m venv venv

# Activate it
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

**This installs:**
- FastAPI (web framework)
- Motor (MongoDB driver)
- Uvicorn (web server)
- And 10+ other packages

#### Step 2: Create .env File

```bash
# Copy the template
cp .env.example .env

# Edit .env with your values:
nano .env
```

**Required values:**

```bash
# MongoDB connection string from Step 1 above
DATABASE_URL=mongodb+srv://ews_user:PASSWORD@cluster.mongodb.net/early_warning?retryWrites=true&w=majority

# AQICN token from Step 3 above
AQICN_API_TOKEN=your_aqicn_token_here

# Leave others blank for now (SMS/Email optional)
ENVIRONMENT=development
```

**⚠️ IMPORTANT:** Never commit `.env` to Git! It has secrets.

#### Step 3: Test Backend Locally

```bash
# Start FastAPI server
python -m uvicorn main:app --reload

# In another terminal, test it:
curl http://localhost:8000/api/health

# Should return:
# {
#   "status": "healthy",
#   "timestamp": "2024-01-20T14:30:00Z",
#   "service": "Early Warning System",
#   "version": "1.0.0"
# }

# Browse API docs:
# Open: http://localhost:8000/docs
# This shows all 30+ endpoints with test interface
```

#### Step 4: Test Frontend

```bash
# Open in browser (local file):
open early_warning_dashboard.html
# Or: file:///path/to/early_warning_dashboard.html

# It will try to call API at /api/* endpoints
# Since backend is running on localhost:8000,
# you may see CORS errors - that's OK for testing
```

**Total: ~1.5 hours**

---

### Day 5-6: Test & Document (1.5 hours)

#### Test All Endpoints

```bash
# Test health check
curl http://localhost:8000/api/health

# Test air quality (should have data)
curl http://localhost:8000/api/air-quality

# Test specific city
curl http://localhost:8000/api/air-quality/Kathmandu

# Test risk score
curl http://localhost:8000/api/risk-score/Kathmandu

# Test contact registration
curl -X POST http://localhost:8000/api/contacts/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "phone_number": "+97712345678",
    "contact_type": "health_worker",
    "facility_name": "Test Hospital",
    "preferred_channels": ["sms"],
    "language": "en",
    "consent_given": true
  }'
```

#### Document What You've Done

```bash
# Create README with notes
echo "## Testing Results" >> README.md
echo "- [x] MongoDB connected" >> README.md
echo "- [x] API running on localhost:8000" >> README.md
echo "- [x] All endpoints responding" >> README.md

# Commit to Git
git add .
git commit -m "Initial setup: Backend, frontend, MongoDB configured"
git push origin main
```

**Total: ~1 hour**

---

## Week 2: Deploy to Production

### Day 8-9: Deploy to Render (2 hours)

#### Step 1: Sign Up for Render

```
Go to: https://render.com
Sign up with GitHub account
Connect your GitHub repo
```

#### Step 2: Create Web Service

```
1. Click "New +" button
2. Select "Web Service"
3. Connect repository: "early-warning-system"
4. Service name: "early-warning-api"
5. Environment: Python 3.11
6. Build command: pip install -r requirements.txt
7. Start command: uvicorn main:app --host 0.0.0.0 --port 8000
8. Plan: Starter ($7/month)
9. Click "Create Web Service"
```

#### Step 3: Add Environment Variables

```
In Render dashboard, go to: Environment
Add all variables from .env:

DATABASE_URL = your_mongodb_connection_string
AQICN_API_TOKEN = your_token
TWILIO_ACCOUNT_SID = (leave blank for MVP)
TWILIO_AUTH_TOKEN = (leave blank for MVP)
RESEND_API_KEY = (leave blank for MVP)
ENVIRONMENT = production
```

#### Step 4: Deploy & Test

```bash
# Render auto-deploys when you push to GitHub
git add .
git commit -m "Ready for production deployment"
git push origin main

# Wait 5-10 minutes for Render to build & deploy
# Check deployment status at: https://render.com/dashboard

# Once deployed, test your API:
curl https://early-warning-api.render.com/api/health

# Browse Swagger docs:
# Visit: https://early-warning-api.render.com/docs
```

**Your API is now LIVE!** 🎉

**Cost:** $7/month on Render
**Domain:** `https://early-warning-api.render.com`

#### Step 5: Deploy Frontend

```bash
# Create a simple web service for frontend

# Option A: Use Render's static site
# 1. Create index.html that redirects to dashboard
# 2. Push to new branch: git checkout -b static-site
# 3. Create new Static Site on Render pointing to this repo
# 4. Your dashboard will be at: https://early-warning.render.com

# Option B: Serve from FastAPI backend
# Add this to main.py:

from fastapi.staticfiles import StaticFiles
app.mount("/", StaticFiles(directory=".", html=True), name="static")

# Option C: Embed frontend in API response
# Serve early_warning_dashboard.html at root
```

**Total: ~1.5 hours**

---

### Day 10-11: Real Data Integration (2 hours)

#### Step 1: Verify Real AQI Data

```bash
# Your backend is already fetching Nepal air quality data
# every 6 hours from AQICN

# Check what data is being stored:
curl https://early-warning-api.render.com/api/air-quality

# Should show all Nepal cities with real AQI values
```

#### Step 2: Register Test Contacts

```bash
# Register a test health worker
curl -X POST https://early-warning-api.render.com/api/contacts/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Dr. Ram Paudel",
    "email": "ram@hospital.example.com",
    "phone_number": "+97712345678",
    "contact_type": "health_worker",
    "facility_name": "Kathmandu Medical Center",
    "preferred_channels": ["email"],
    "language": "en",
    "consent_given": true
  }'

# Check registered contacts:
curl https://early-warning-api.render.com/api/contacts
```

#### Step 3: Test Alerts (Email Optional)

```bash
# For MVP: Email/SMS alerts are logged but not sent
# (requires paid APIs: Twilio, Resend)

# Log an action as if facility responded:
curl -X POST https://early-warning-api.render.com/api/action-log \
  -H "Content-Type: application/json" \
  -d '{
    "facility_id": "kathmandu_medical_center",
    "action_type": "stocked_oxygen",
    "details": "Received 50 oxygen cylinders"
  }'
```

**Total: ~1 hour**

---

### Day 12-14: Final Testing & Optimization (2 hours)

#### Step 1: Monitor Logs

```bash
# Go to Render dashboard
# Services → early-warning-api → Logs
# Check for any errors
# Verify data syncing every 6 hours
```

#### Step 2: Optimize Performance

```bash
# Add database indexes (FastAPI does this on startup)
# Add caching for frequently accessed data
# Monitor response times in /docs
```

#### Step 3: Documentation

```bash
# Create deployment notes
cat > DEPLOYMENT.md << 'EOF'
# Deployment Notes

## Production URLs
- API: https://early-warning-api.render.com
- Dashboard: https://early-warning-api.render.com/early_warning_dashboard.html
- API Docs: https://early-warning-api.render.com/docs

## Key Endpoints
- GET /api/health - Health check
- GET /api/air-quality - All cities
- GET /api/air-quality/{city} - Specific city
- POST /api/contacts/register - Register for alerts
- POST /api/action-log - Log facility action

## Monitoring
- Air quality syncs every 6 hours
- Check logs in Render dashboard
- Alerts trigger when AQI > 150

## Maintenance
- Update .env variables in Render dashboard
- Monitor MongoDB usage (free tier: 512MB)
- Review deployment logs weekly
EOF

git add DEPLOYMENT.md
git commit -m "Production deployment complete"
git push origin main
```

**Total: ~1.5 hours**

---

## Checklist: What You've Built

✅ **Backend API**
- 30+ REST endpoints
- Real-time air quality data from AQICN
- Contact registration & verification
- Alert broadcasting system
- Facility action logging
- Analytics endpoints

✅ **Frontend Dashboard**
- Single HTML file (no build needed)
- Real-time AQI display
- 24-hour trends
- Alert registration form
- Action logging interface
- Responsive mobile design

✅ **Database**
- MongoDB Atlas (free 512MB)
- Automated backups
- Indexes for performance

✅ **Deployment**
- Live on Render.com ($7/month)
- Auto-deploys on git push
- Health checks enabled
- Environment variables configured

✅ **Monitoring**
- Logs accessible in Render
- API documentation at /docs
- Data export endpoint

---

## Next Steps: Optional Integrations

### Add SMS Alerts (Cost: ~$100/month during high season)

```bash
# Get Twilio account: https://www.twilio.com/
# Add to .env:
TWILIO_ACCOUNT_SID=your_sid
TWILIO_AUTH_TOKEN=your_token
TWILIO_PHONE_NUMBER=+14155238886

# Uncomment SMS code in main.py
# Alerts will now send via SMS
```

### Add Email Alerts (Cost: ~$20/month or free tier)

```bash
# Get Resend account: https://resend.com/
# Add to .env:
RESEND_API_KEY=your_key
RESEND_FROM_EMAIL=noreply@example.com

# Uncomment email code in main.py
# Alerts will now send via email
```

### Add WhatsApp (Cost: ~$0.005/message)

```bash
# WhatsApp uses Twilio
# When SMS code is enabled, uncomment WhatsApp
# Messages send to WhatsApp sandbox or production numbers
```

---

## Troubleshooting

### "MongoDB connection refused"

```bash
# Check:
1. DATABASE_URL in .env is correct
2. IP whitelist includes your machine
3. Database user has correct password
4. Cluster status is READY (not grayed out)

# Test locally:
mongosh "mongodb+srv://user:pass@cluster.mongodb.net/early_warning"
```

### "AQICN API returning 404"

```bash
# Check:
1. AQICN_API_TOKEN is correct
2. Station IDs are valid:
   - Kathmandu: H14868
   - Pokhara: H14867
   - Lalitpur: H10495
   - Biratnagar: H10491

# Test token:
curl "https://api.waqi.info/feed/@H14868/?token=YOUR_TOKEN"
```

### "Frontend shows "error loading data"

```bash
# If backend is on Render but frontend is local:
# Browser blocks API calls (CORS)

# Solution: Serve frontend from same Render service
# Or use production URLs in dashboard.html
```

### "Port 8000 already in use"

```bash
# Another app is using port 8000
# Kill it:
lsof -i :8000
kill -9 <PID>

# Or use different port:
uvicorn main:app --port 8001
```

---

## Timeline Summary

| Time | Task | Duration |
|------|------|----------|
| Day 1-2 | MongoDB + GitHub setup | 2h |
| Day 3-4 | Local development | 2h |
| Day 5-6 | Testing & documentation | 1.5h |
| Day 8-9 | Deploy to Render | 2h |
| Day 10-11 | Real data integration | 2h |
| Day 12-14 | Finalize & optimize | 2h |
| **Total** | | **11.5 hours** |

**Plus setup time:** ~30 minutes (GitHub, MongoDB, AQICN signup)
**Grand total:** ~12 hours of work

---

## Cost Analysis (First 6 Months)

| Service | Cost | Notes |
|---------|------|-------|
| Render | $42 | $7/month, auto-scales |
| MongoDB | $0 | Free tier 512MB |
| AQICN API | $0 | Free tier 50 calls/hour |
| OpenWeather | $0 | Free tier 1000 calls/day |
| SMS (optional) | $0 | MVP without SMS |
| **Total** | **$42** | Bare minimum MVP |

Add SMS alerts: +$300 (3 months × $100 high AQ season)

---

## You're Ready!

You now have a **production-ready, real-time air quality monitoring system** that:

- Tracks respiratory health risks
- Alerts health workers during high pollution
- Logs facility responses
- Exports data for impact evaluation
- Scales from 1 to 1000+ health workers

This is exactly what UNICEF needs to see. 🚀

---

## Support

- **FastAPI Docs:** https://fastapi.tiangolo.com/
- **MongoDB Docs:** https://docs.mongodb.com/
- **Render Docs:** https://render.com/docs
- **AQICN API:** https://aqicn.org/api/

Good luck! 💪
