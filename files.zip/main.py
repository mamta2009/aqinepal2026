"""
Early Warning System - FastAPI Backend
Government of Nepal, Ministry of Population and Environment
Air Quality Monitoring & Respiratory Health Alerts

This backend provides:
- Real-time air quality data from AQICN (pollution.gov.np)
- Contact registration & verification (SMS/WhatsApp/Email)
- Alert broadcasting to health workers
- Facility action logging
- Analytics & reporting

Stack: FastAPI + Motor (async MongoDB) + Twilio + Resend
"""

import os
import logging
from datetime import datetime, timedelta
from typing import Optional, List
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from pydantic import BaseModel, EmailStr
import httpx
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================================
# ENVIRONMENT VARIABLES
# ============================================================================

DATABASE_URL = os.getenv("DATABASE_URL", "mongodb://localhost:27017/early_warning")
AQICN_TOKEN = os.getenv("AQICN_API_TOKEN", "")
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_PHONE = os.getenv("TWILIO_PHONE_NUMBER", "")
RESEND_API_KEY = os.getenv("RESEND_API_KEY", "")
RESEND_FROM_EMAIL = os.getenv("RESEND_FROM_EMAIL", "")
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")

# Nepal monitoring stations (AQICN station IDs)
NEPAL_STATIONS = {
    "Kathmandu": "H14868",
    "Pokhara": "H14867",
    "Lalitpur": "H10495",
    "Biratnagar": "H10491",
    "Janakpur": "H13889",
    "Birgunj": "H13890",
}

# ============================================================================
# MONGODB CONNECTION
# ============================================================================

class MongoDBConnection:
    """Manage MongoDB connection lifecycle."""
    client: AsyncIOMotorClient = None
    db: AsyncIOMotorDatabase = None


mongodb = MongoDBConnection()


async def connect_mongodb():
    """Connect to MongoDB."""
    try:
        mongodb.client = AsyncIOMotorClient(DATABASE_URL)
        mongodb.db = mongodb.client.early_warning
        await mongodb.db.command("ping")
        logger.info("✓ MongoDB connected")
    except Exception as e:
        logger.error(f"✗ MongoDB connection failed: {e}")
        raise


async def close_mongodb():
    """Close MongoDB connection."""
    if mongodb.client:
        mongodb.client.close()
        logger.info("✓ MongoDB disconnected")


async def setup_database():
    """Create indexes for collections."""
    db = mongodb.db
    
    try:
        # Contacts collection indexes
        await db.contacts.create_index("email", unique=True)
        await db.contacts.create_index("phone_number")
        await db.contacts.create_index("facility_id")
        await db.contacts.create_index("verification_status")
        
        # Air quality indexes
        await db.air_quality.create_index("city", unique=True)
        await db.air_quality.create_index("timestamp")
        await db.air_quality.create_index("station_id")
        
        # Notification logs indexes
        await db.notification_logs.create_index("recipient_id")
        await db.notification_logs.create_index("timestamp")
        await db.notification_logs.create_index("status")
        
        # Alerts indexes
        await db.alerts.create_index("city")
        await db.alerts.create_index("timestamp")
        
        # Action logs indexes
        await db.action_logs.create_index("facility_id")
        await db.action_logs.create_index("timestamp")
        
        logger.info("✓ Database indexes created")
    except Exception as e:
        logger.warning(f"Index creation (some may already exist): {e}")


# ============================================================================
# PYDANTIC MODELS
# ============================================================================

class ContactRegistration(BaseModel):
    """Contact registration request."""
    name: str
    email: EmailStr
    phone_number: str  # E.164 format: +1234567890
    whatsapp_number: Optional[str] = None
    contact_type: str  # health_worker, parent, admin
    facility_name: str
    preferred_channels: List[str]  # sms, whatsapp, email
    language: str = "en"  # en, ne
    consent_given: bool


class ContactVerification(BaseModel):
    """Contact verification request."""
    contact_id: str
    verification_code: str


class NotificationRequest(BaseModel):
    """Send notification request."""
    recipient_id: str
    channel: str  # sms, whatsapp, email
    message: str
    subject: Optional[str] = None


class AlertBroadcast(BaseModel):
    """Broadcast alert request."""
    city: str
    aqi_value: int
    aqi_level: str  # LOW, MODERATE, HIGH, SEVERE, HAZARDOUS
    recipient_type: str = "health_worker"  # health_worker, parent, admin, all
    message_override: Optional[str] = None


class ActionLog(BaseModel):
    """Log facility action."""
    facility_id: str
    action_type: str  # stocked_oxygen, staff_called, prepared_ward, etc
    details: Optional[str] = None


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def convert_aqi_to_level(aqi: Optional[int]) -> str:
    """Convert numeric AQI to health advisory level."""
    if aqi is None:
        return "UNKNOWN"
    elif aqi <= 50:
        return "GOOD"
    elif aqi <= 100:
        return "MODERATE"
    elif aqi <= 150:
        return "UNHEALTHY_FOR_SENSITIVE_GROUPS"
    elif aqi <= 200:
        return "UNHEALTHY"
    elif aqi <= 300:
        return "VERY_UNHEALTHY"
    else:
        return "HAZARDOUS"


def format_phone_number(phone: str) -> str:
    """Normalize phone number to E.164 format."""
    # Remove spaces, dashes, parentheses
    phone = phone.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    
    # If doesn't start with +, assume Nepal (+977)
    if not phone.startswith("+"):
        phone = "+977" + phone.lstrip("0")
    
    return phone


# ============================================================================
# AIR QUALITY FUNCTIONS
# ============================================================================

async def fetch_aqicn_data(station_id: str) -> Optional[dict]:
    """Fetch AQI data from AQICN for a Nepal monitoring station."""
    try:
        url = f"https://api.waqi.info/feed/@{station_id}/?token={AQICN_TOKEN}"
        async with httpx.AsyncClient() as client:
            response = await client.get(url, timeout=10.0)
            response.raise_for_status()
            data = response.json()
        
        if data['status'] != 'ok':
            logger.warning(f"AQICN API error for {station_id}: {data.get('data')}")
            return None
        
        aqicn_data = data['data']
        
        return {
            "city": aqicn_data.get('city', {}).get('name', 'Unknown'),
            "aqi": aqicn_data.get('aqi'),
            "aqi_level": convert_aqi_to_level(aqicn_data.get('aqi')),
            "pm25": aqicn_data.get('iaqi', {}).get('pm25', {}).get('v'),
            "pm10": aqicn_data.get('iaqi', {}).get('pm10', {}).get('v'),
            "o3": aqicn_data.get('iaqi', {}).get('o3', {}).get('v'),
            "no2": aqicn_data.get('iaqi', {}).get('no2', {}).get('v'),
            "so2": aqicn_data.get('iaqi', {}).get('so2', {}).get('v'),
            "co": aqicn_data.get('iaqi', {}).get('co', {}).get('v'),
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "source": "aqicn",
            "station_id": station_id
        }
    except Exception as e:
        logger.error(f"Error fetching AQICN data for {station_id}: {e}")
        return None


async def sync_nepal_air_quality():
    """Background job to sync Nepal air quality data (run every 6 hours)."""
    logger.info("[SYNC] Starting air quality data sync...")
    
    results = []
    for city, station_id in NEPAL_STATIONS.items():
        aqi_data = await fetch_aqicn_data(station_id)
        if aqi_data:
            # Store in MongoDB
            await mongodb.db.air_quality.update_one(
                {"station_id": station_id},
                {"$set": aqi_data},
                upsert=True
            )
            results.append(aqi_data)
            
            # Check if alert threshold crossed
            aqi_value = aqi_data['aqi']
            if aqi_value and aqi_value >= 150:  # Alert if UNHEALTHY+
                await check_and_trigger_alert(aqi_data)
            
            logger.info(f"✓ {city}: AQI {aqi_value} ({aqi_data['aqi_level']})")
        else:
            logger.warning(f"✗ {city}: Failed to fetch")
    
    logger.info(f"[SYNC] Completed: {len(results)}/{len(NEPAL_STATIONS)} stations")
    return results


async def check_and_trigger_alert(aqi_data: dict):
    """Check if alert should be triggered and broadcast if needed."""
    city = aqi_data.get('city')
    aqi_value = aqi_data.get('aqi')
    aqi_level = aqi_data.get('aqi_level')
    
    # Get last alert for this city
    last_alert = await mongodb.db.alerts.find_one(
        {"city": city},
        sort=[("timestamp", -1)]
    )
    
    # Only alert if level changed or 6+ hours passed
    if last_alert:
        if last_alert["aqi_level"] == aqi_level:
            if datetime.fromisoformat(last_alert["timestamp"].replace("Z", "+00:00")) > datetime.utcnow() - timedelta(hours=6):
                return
    
    # Trigger broadcast
    alert_data = AlertBroadcast(
        city=city,
        aqi_value=aqi_value,
        aqi_level=aqi_level,
        recipient_type="health_worker"
    )
    await broadcast_alert(alert_data)


# ============================================================================
# NOTIFICATION FUNCTIONS
# ============================================================================

async def send_sms(phone_number: str, message: str) -> dict:
    """Send SMS via Twilio."""
    if not TWILIO_ACCOUNT_SID:
        logger.warning("SMS not configured (TWILIO_ACCOUNT_SID not set)")
        return {"success": False, "error": "SMS not configured"}
    
    try:
        # TODO: Implement Twilio SMS sending
        # This requires: pip install twilio
        logger.info(f"[SMS] Would send to {phone_number}: {message}")
        return {
            "success": True,
            "channel": "sms",
            "phone": phone_number,
            "status": "queued"
        }
    except Exception as e:
        logger.error(f"SMS error: {e}")
        return {"success": False, "error": str(e)}


async def send_whatsapp(phone_number: str, message: str) -> dict:
    """Send WhatsApp via Twilio."""
    if not TWILIO_ACCOUNT_SID:
        logger.warning("WhatsApp not configured (TWILIO_ACCOUNT_SID not set)")
        return {"success": False, "error": "WhatsApp not configured"}
    
    try:
        # TODO: Implement Twilio WhatsApp sending
        logger.info(f"[WhatsApp] Would send to {phone_number}: {message}")
        return {
            "success": True,
            "channel": "whatsapp",
            "phone": phone_number,
            "status": "queued"
        }
    except Exception as e:
        logger.error(f"WhatsApp error: {e}")
        return {"success": False, "error": str(e)}


async def send_email(to_email: str, subject: str, html_content: str) -> dict:
    """Send email via Resend API."""
    if not RESEND_API_KEY:
        logger.warning("Email not configured (RESEND_API_KEY not set)")
        return {"success": False, "error": "Email not configured"}
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.resend.com/emails",
                headers={"Authorization": f"Bearer {RESEND_API_KEY}"},
                json={
                    "from": RESEND_FROM_EMAIL,
                    "to": to_email,
                    "subject": subject,
                    "html": html_content
                }
            )
            response.raise_for_status()
            data = response.json()
            
            logger.info(f"[Email] Sent to {to_email}")
            return {
                "success": True,
                "channel": "email",
                "email": to_email,
                "status": "sent"
            }
    except Exception as e:
        logger.error(f"Email error: {e}")
        return {"success": False, "error": str(e)}


async def broadcast_alert(alert: AlertBroadcast):
    """Broadcast alert to recipients."""
    # Find matching contacts
    query = {
        "verification_status": "verified",
        "active": True
    }
    
    if alert.recipient_type != "all":
        query["contact_type"] = alert.recipient_type
    
    contacts = await mongodb.db.contacts.find(query).to_list(None)
    
    if not contacts:
        logger.warning(f"No verified contacts found for {alert.recipient_type}")
        return
    
    # Build message
    if alert.message_override:
        message = alert.message_override
    else:
        emoji = "🔴" if alert.aqi_level in ["UNHEALTHY", "VERY_UNHEALTHY", "HAZARDOUS"] else "🟡"
        message = f"{emoji} {alert.aqi_level} air quality in {alert.city}\nAQI: {alert.aqi_value}\nCheck facility oxygen stock"
    
    # Send to each contact via their preferred channels
    for contact in contacts:
        for channel in contact.get("preferred_channels", []):
            if channel == "sms" and contact.get("phone_number"):
                await send_sms(contact["phone_number"], message)
            elif channel == "whatsapp" and contact.get("whatsapp_number"):
                await send_whatsapp(contact["whatsapp_number"], message)
            elif channel == "email" and contact.get("email"):
                await send_email(
                    contact["email"],
                    f"Air Quality Alert: {alert.city}",
                    f"<p>{message.replace(chr(10), '<br>')}</p>"
                )
    
    # Log alert
    await mongodb.db.alerts.insert_one({
        "city": alert.city,
        "aqi_value": alert.aqi_value,
        "aqi_level": alert.aqi_level,
        "recipient_count": len(contacts),
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })
    
    logger.info(f"[ALERT] Broadcast {alert.aqi_level} alert in {alert.city} to {len(contacts)} contacts")


# ============================================================================
# APP STARTUP/SHUTDOWN
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handle app startup and shutdown."""
    # Startup
    await connect_mongodb()
    await setup_database()
    await sync_nepal_air_quality()  # Fetch data on startup
    
    # Schedule periodic sync (every 6 hours)
    # Note: In production, use APScheduler for this
    
    logger.info("✓ Early Warning System started")
    yield
    
    # Shutdown
    await close_mongodb()
    logger.info("✓ Early Warning System stopped")


# ============================================================================
# FASTAPI APP
# ============================================================================

app = FastAPI(
    title="Early Warning System API",
    description="Government of Nepal - Air Quality & Respiratory Health Alerts",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# API ENDPOINTS
# ============================================================================

# Health Check
@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "service": "Early Warning System",
        "version": "1.0.0"
    }


# Air Quality Endpoints
@app.get("/api/air-quality")
async def get_all_air_quality():
    """Get air quality for all monitored cities."""
    data = await mongodb.db.air_quality.find({}).to_list(None)
    return {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "count": len(data),
        "cities": data
    }


@app.get("/api/air-quality/{city}")
async def get_air_quality(city: str):
    """Get current air quality for a city."""
    air_quality = await mongodb.db.air_quality.find_one(
        {"city": {"$regex": city, "$options": "i"}}
    )
    
    if not air_quality:
        raise HTTPException(status_code=404, detail=f"No data for {city}")
    
    return {
        "city": air_quality["city"],
        "aqi": air_quality["aqi"],
        "aqi_level": air_quality["aqi_level"],
        "pm25": air_quality.get("pm25"),
        "pm10": air_quality.get("pm10"),
        "o3": air_quality.get("o3"),
        "no2": air_quality.get("no2"),
        "timestamp": air_quality["timestamp"]
    }


@app.get("/api/risk-score/{city}")
async def get_risk_score(city: str):
    """Get respiratory risk score (0-100) for a city based on AQI."""
    air_quality = await mongodb.db.air_quality.find_one(
        {"city": {"$regex": city, "$options": "i"}}
    )
    
    if not air_quality:
        raise HTTPException(status_code=404, detail=f"No data for {city}")
    
    # Convert AQI to risk score (0-100)
    aqi = air_quality.get("aqi", 0)
    risk_score = min(100, max(0, int(aqi / 3)))  # AQI 300 = 100% risk
    
    return {
        "city": air_quality["city"],
        "aqi": aqi,
        "risk_score": risk_score,
        "risk_level": air_quality["aqi_level"],
        "timestamp": air_quality["timestamp"]
    }


# Contact Management
@app.post("/api/contacts/register")
async def register_contact(contact: ContactRegistration, background_tasks: BackgroundTasks):
    """Register a new contact."""
    # Normalize phone number
    phone = format_phone_number(contact.phone_number)
    
    # Check if email already exists
    existing = await mongodb.db.contacts.find_one({"email": contact.email})
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")
    
    # Create contact
    contact_doc = {
        "name": contact.name,
        "email": contact.email,
        "phone_number": phone,
        "whatsapp_number": contact.whatsapp_number,
        "contact_type": contact.contact_type,
        "facility_name": contact.facility_name,
        "preferred_channels": contact.preferred_channels,
        "language": contact.language,
        "consent_given": contact.consent_given,
        "verification_status": "pending",
        "active": True,
        "created_at": datetime.utcnow().isoformat() + "Z"
    }
    
    result = await mongodb.db.contacts.insert_one(contact_doc)
    contact_id = str(result.inserted_id)
    
    # Log consent
    await mongodb.db.consent_records.insert_one({
        "contact_id": contact_id,
        "email": contact.email,
        "consent_given": contact.consent_given,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })
    
    logger.info(f"✓ Registered contact: {contact.email} ({contact_id})")
    
    return {
        "contact_id": contact_id,
        "status": "registered",
        "message": "Check your email/SMS for verification code"
    }


@app.get("/api/contacts")
async def list_contacts(facility_id: Optional[str] = None, limit: int = 100):
    """List all registered contacts."""
    query = {}
    if facility_id:
        query["facility_id"] = facility_id
    
    contacts = await mongodb.db.contacts.find(query).limit(limit).to_list(None)
    
    # Remove sensitive fields
    for contact in contacts:
        contact.pop("phone_number", None)
        contact.pop("whatsapp_number", None)
    
    return {
        "count": len(contacts),
        "contacts": contacts
    }


# Notifications
@app.post("/api/notifications/send")
async def send_notification(req: NotificationRequest):
    """Send notification to a contact."""
    # Get contact
    contact = await mongodb.db.contacts.find_one({"_id": req.recipient_id})
    if not contact:
        raise HTTPException(status_code=404, detail="Contact not found")
    
    if not contact.get("consent_given"):
        raise HTTPException(status_code=403, detail="Contact has not given consent")
    
    # Send based on channel
    result = None
    if req.channel == "sms":
        result = await send_sms(contact["phone_number"], req.message)
    elif req.channel == "whatsapp":
        result = await send_whatsapp(contact["whatsapp_number"], req.message)
    elif req.channel == "email":
        result = await send_email(contact["email"], req.subject or "Alert", f"<p>{req.message}</p>")
    else:
        raise HTTPException(status_code=400, detail="Invalid channel")
    
    # Log notification
    await mongodb.db.notification_logs.insert_one({
        "recipient_id": contact["_id"],
        "channel": req.channel,
        "status": "sent" if result.get("success") else "failed",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })
    
    return result


# Alerts
@app.post("/api/alerts/broadcast")
async def broadcast_alert_endpoint(alert: AlertBroadcast, background_tasks: BackgroundTasks):
    """Broadcast alert to contacts."""
    background_tasks.add_task(broadcast_alert, alert)
    
    return {
        "status": "broadcasting",
        "city": alert.city,
        "aqi_level": alert.aqi_level
    }


@app.get("/api/alerts")
async def get_alerts(days: int = 7, limit: int = 50):
    """Get recent alerts."""
    cutoff = datetime.utcnow() - timedelta(days=days)
    
    alerts = await mongodb.db.alerts.find({
        "timestamp": {"$gte": cutoff.isoformat() + "Z"}
    }).sort("timestamp", -1).limit(limit).to_list(None)
    
    return {
        "count": len(alerts),
        "alerts": alerts
    }


# Facility Actions
@app.post("/api/action-log")
async def log_action(action: ActionLog):
    """Log a facility action in response to alert."""
    action_doc = {
        "facility_id": action.facility_id,
        "action_type": action.action_type,
        "details": action.details,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
    
    result = await mongodb.db.action_logs.insert_one(action_doc)
    
    logger.info(f"✓ Logged action: {action.action_type} at {action.facility_id}")
    
    return {
        "action_id": str(result.inserted_id),
        "status": "logged"
    }


@app.get("/api/action-log/{facility_id}")
async def get_facility_actions(facility_id: str, days: int = 30):
    """Get actions logged by a facility."""
    cutoff = datetime.utcnow() - timedelta(days=days)
    
    actions = await mongodb.db.action_logs.find({
        "facility_id": facility_id,
        "timestamp": {"$gte": cutoff.isoformat() + "Z"}
    }).sort("timestamp", -1).to_list(None)
    
    return {
        "facility_id": facility_id,
        "count": len(actions),
        "actions": actions
    }


# Analytics
@app.get("/api/analytics/notifications")
async def get_notification_analytics(days: int = 7):
    """Get notification statistics."""
    cutoff = datetime.utcnow() - timedelta(days=days)
    
    # Total notifications
    total = await mongodb.db.notification_logs.count_documents({
        "timestamp": {"$gte": cutoff.isoformat() + "Z"}
    })
    
    # By channel
    by_channel = await mongodb.db.notification_logs.aggregate([
        {"$match": {"timestamp": {"$gte": cutoff.isoformat() + "Z"}}},
        {"$group": {
            "_id": "$channel",
            "total": {"$sum": 1},
            "success": {
                "$sum": {"$cond": [{"$eq": ["$status", "sent"]}, 1, 0]}
            }
        }}
    ]).to_list(None)
    
    return {
        "days": days,
        "total": total,
        "by_channel": by_channel
    }


@app.get("/api/analytics/contacts")
async def get_contact_analytics():
    """Get contact statistics."""
    total = await mongodb.db.contacts.count_documents({})
    verified = await mongodb.db.contacts.count_documents({"verification_status": "verified"})
    
    return {
        "total_contacts": total,
        "verified_contacts": verified,
        "verification_rate": f"{(verified/total*100):.1f}%" if total > 0 else "0%"
    }


# Data Export
@app.get("/api/data/export")
async def export_data(days: int = 30):
    """Export air quality and alert data."""
    cutoff = datetime.utcnow() - timedelta(days=days)
    
    air_quality = await mongodb.db.air_quality.find({}).to_list(None)
    alerts = await mongodb.db.alerts.find({
        "timestamp": {"$gte": cutoff.isoformat() + "Z"}
    }).to_list(None)
    
    return {
        "export_date": datetime.utcnow().isoformat() + "Z",
        "air_quality": air_quality,
        "alerts": alerts
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=ENVIRONMENT == "development"
    )
